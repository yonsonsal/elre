from ..servicios.serviciosCapas import ServiciosCapas

class Codigueras:

	def __procesarCodiguera(self, nombreUsuario, nombreCodiguera, pkNombre, valueNombre, aplicacion):
		responseCodiguera = ServiciosCapas.obtenerCodiguerasData(nombreUsuario, aplicacion)
		diccionarioCodiguera = dict()
		for datos in responseCodiguera:
			if datos["Codiguera"] == nombreCodiguera:
				tuplas = datos["Data"]
				for registro in tuplas:
					diccionarioCodiguera[registro[valueNombre]]=registro[pkNombre]
		return diccionarioCodiguera

	@staticmethod
	def procesarDatosCapaCodiguera(nombreUsuario, nombreCapa, aplicacion):
		atributosCapa = ServiciosCapas.obtenerAtributosCapa(nombreUsuario, nombreCapa, aplicacion)
		comboValue = atributosCapa["comboValue"]
		comboDesciption = atributosCapa["comboLabel"]
		procCod = Codigueras()
		valoresCodiguera = procCod.__procesarCodiguera(nombreUsuario, nombreCapa, comboValue, comboDesciption, aplicacion)
		return valoresCodiguera

	@staticmethod
	def obtenerDatosCapaCodigueraRelacionValores(nombreUsuario, nombreCapa, aplicacion):
		atributosCapa = ServiciosCapas.obtenerAtributosCapa(nombreUsuario, nombreCapa, aplicacion)
		comboValue = atributosCapa["comboValue"]
		comboDesciption = atributosCapa["comboLabel"]
		return comboValue, comboDesciption
