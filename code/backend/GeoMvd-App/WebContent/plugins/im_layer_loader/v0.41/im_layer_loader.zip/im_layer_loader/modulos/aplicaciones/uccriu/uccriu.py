from .funcionesUccriu import FuncionesUccriu


class Uccriu:

    @staticmethod
    def procesarAplicacion(*args):
        workspace = args[0]
        FuncionesUccriu.disponibilizarFuncionesParaExpresiones()        

    @staticmethod
    def procesarCapasAplicacion(*args):
        workspace = args[0]
        layerName = args[1]
        
    @staticmethod
    def completarConfigAplicacion(*args):
        print("pasa completar funciones uccriu")
        FuncionesUccriu.filtrarDescripcionRemocion()
