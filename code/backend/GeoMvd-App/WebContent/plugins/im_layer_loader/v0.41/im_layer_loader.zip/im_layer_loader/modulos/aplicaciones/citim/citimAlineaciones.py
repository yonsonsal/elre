from .funcionesCitim import FuncionesCitim
class CitimAlineaciones:

    @staticmethod
    def procesarAplicacion(*args):
        workspace = args[0]
        print("procesarAplicacion citim")

    @staticmethod
    def procesarCapasAplicacion(*args):
        workspace = args[0]
        layerName = args[1]
        print("procesarCapasAplicacion citim")

    @staticmethod
    def completarConfigAplicacion(*args):
        FuncionesCitim.armarUnionTrazosProyecto()