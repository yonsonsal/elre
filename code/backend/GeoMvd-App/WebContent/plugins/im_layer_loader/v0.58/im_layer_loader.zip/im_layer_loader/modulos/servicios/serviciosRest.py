import logging

import requests
from PyQt5.QtWidgets import QMessageBox
from requests.auth import HTTPBasicAuth
import json
from PyQt5.QtWidgets import QMessageBox

class ServiciosRest :

	@staticmethod
	def invocarRestGet(urlServicio):
		try:
			headers = {'Accept': 'application/json'}
			with requests.get(urlServicio, headers=headers, verify=True) as response:
				response.raise_for_status()  # Levanta una excepción para códigos de estado de error
				return response.json()
		except requests.exceptions.RequestException as error:
			if response.status_code == 404:
				logging.error(f'Error en "invocarRestGet" en ServiciosRest. No se encuentra la metadata: status_code: {response.status_code}. response.text: {response.text}. response.reason: {response.reason}. urlServicio: {urlServicio}')
			else:
				logging.error(f'Error en el request. En "invocarRestGet" en ServiciosRest: {type(error).__name__} : {error}. urlServicio: {urlServicio}. response:{response}')
			return None
		except json.JSONDecodeError as error:
			logging.error(f"Error al parsear JSON: {error}. URL: {urlServicio}, Respuesta: {response.text}")
			return None
		except Exception as error:
			logging.error(f"Error inesperado: {type(error).__name__} : {error}. URL: {urlServicio}")
			return None


	@staticmethod
	def invocarRestGetAuth(urlServicio, usuario, password):
		try:
			headers = {'Accept': 'application/json'}
			auth=HTTPBasicAuth(usuario, password)
			response = requests.get(urlServicio, headers=headers, auth=auth)
			return response.json()
		except Exception as error:
			logging.error(f'Error en la red. En "invocarRestGetAuth" en ServiciosRest: {type(error).__name__} : {error}. urlServicio: {urlServicio}')
			return None

	@staticmethod
	def invocarRestGetAuthSld(urlServicio, usuario, password):
		try:
			headers = {'Accept': 'application/vnd.ogc.sld+xml'}
			auth=HTTPBasicAuth(usuario, password)
			response = requests.get(urlServicio, headers=headers, auth=auth)
			return response.content
		except Exception as error:
			logging.error(f'Error en la red. En "invocarRestGetAuthSld" en ServiciosRest: {type(error).__name__} : {error}. urlServicio: {urlServicio}')
			return None

	@staticmethod
	def invocarRestPost(urlServicio, data):
		try:
			headers = {'Accept': 'application/json'}
			response = requests.post(urlServicio, json=data, headers=headers)
			return response.json()
		except Exception as error:
			logging.error(f'Error en la red. En "invocarRestPost" en ServiciosRest: {type(error).__name__} : {error}. urlServicio: {urlServicio}')
			return None

	@staticmethod
	def invocarRestPostCSV(urlServicio, data):
		try:
			headers = {'Accept': 'text/csv'}
			response = requests.post(urlServicio, json=data, stream=True, headers=headers)
			return response
		except Exception as error:
			logging.error(f'Error en la red. En "invocarRestPostCSV" en ServiciosRest: {type(error).__name__} : {error}. urlServicio: {urlServicio}')
			return None