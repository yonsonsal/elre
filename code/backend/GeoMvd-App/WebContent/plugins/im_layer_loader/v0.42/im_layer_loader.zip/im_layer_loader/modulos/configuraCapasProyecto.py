from qgis.core import QgsMapLayerType
from qgis.core import QgsProject

from .servicios.serviciosCapas import ServiciosCapas
from .formularios.formulario import Formulario
from .utilidades.funcionesExportacion import FuncionesExportacion
from .utilidades.funcionesGenericas import FuncionesGenericas
from .utilidades.funcionesMapa import FuncionesMapa


class ConfiguraCapasProyecto :

	def __procesarDatosCapa(self, nombreUsuario, nombreCapa, workspace):
		retorno = ""
		atributosCapa = ServiciosCapas.obtenerAtributosCapa(nombreUsuario, nombreCapa, workspace)
		if atributosCapa is not None:
			atributosFormulario = atributosCapa["atributos"]
			Formulario.configurarFormulario(nombreUsuario, nombreCapa, atributosCapa, atributosFormulario, workspace)
			#PARA DETECTAR SI LA CAPA ES EDITABLE O NO VEMOS EL ATRIBUTO EDITABLE DEL .APP
			#SI VIENE QUE ES FALSE LA MARCAMOS COMO SOLE LECTURA, SINO QUEDA POR DEFECTO EDITABLE (PARA WFS)
			editable = atributosCapa["editable"]
			if not editable:
				FuncionesMapa.setCapaSoloLectura(nombreCapa, True)
			retorno = ""
		else:
			retorno = "No Existe Metadata De La Capa: " + nombreCapa
		
		return retorno

	@staticmethod
	def configuraCapasProyecto():
		retorno = ""
		if len(QgsProject.instance().mapLayers().values()) > 0:
			for layer in QgsProject.instance().mapLayers().values():
				if layer.type() == QgsMapLayerType.VectorLayer and len(layer.name().split(":")) > 1:
					workspace = ""
					layername = ""
					if len(layer.name().split(":")) > 1:
						workspace, layername = FuncionesGenericas.getLayerName(layer.name())
						layer.setName(layername)
					nombreUsuario = FuncionesGenericas.getUserLayer(layer.source())
					nombreCapa = layer.name()
					conf = ConfiguraCapasProyecto()
					retornoString = conf.__procesarDatosCapa(nombreUsuario, nombreCapa, workspace)
					if retornoString!="":
						retorno += "\n"+retornoString
					if workspace != "":
						layer.setName(workspace+":"+layername)
		else:
			retorno = "\nNo Existen Capas Agregadas"
		return retorno
