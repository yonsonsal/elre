import os
import configparser

class ConfigProperties:

	def __cargarAmbiente(self):
		thisfolder = os.path.dirname(os.path.abspath(__file__))
		initfile = os.path.join(thisfolder, 'config.properties')
		config = configparser.ConfigParser()
		config.read(initfile)
		return config

	def __cargarProperties(self, ambiente):
		thisfolder = os.path.dirname(os.path.abspath(__file__))
		initfile = None
		if ambiente == "local":
			initfile = os.path.join(thisfolder, 'config.local.properties')
		elif ambiente == "desarrollo":
			initfile = os.path.join(thisfolder, 'config.desa.properties')
		elif ambiente == "produccion":
			initfile = os.path.join(thisfolder, 'config.prod.properties')
		config = configparser.ConfigParser()
		config.read(initfile)
		return config
	
	@staticmethod
	def getPropery(seccion, propiedad):
		confProp = ConfigProperties()
		ambiente = confProp.__cargarAmbiente().get("AMBIENTE", "ambiente")
		prop = confProp.__cargarProperties(ambiente)
		return prop.get(seccion, propiedad)
