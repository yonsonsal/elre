from numpy.ma import nomask


class FuncionesDfr:

    @staticmethod
    def renumerarPosicionesRecorrido(nombreCapa):
        print("Renumerando las posiciones recorrido de la capa " + nombreCapa)