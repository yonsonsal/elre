from .funcionesDfr import FuncionesDfr
from ...utilidades.funcionesGenericas import FuncionesGenericas


class Dfr:

    @staticmethod
    def procesarAplicacion(*args):
        workspace = args[0]
        layerName = args[1]

        if layerName == "dfr:E_DF_POSICIONES_RECORRIDO":

            nombreAccion =  "Renumerar Posiciones"
            nombreObjetoAccion = 'RenumerarPosiciones'

            FuncionesGenericas.cargarOpcionAccionCapa(
                layerName,
                nombreAccion,
                nombreObjetoAccion,
                lambda: FuncionesDfr.renumerarPosicionesRecorrido(layerName))
