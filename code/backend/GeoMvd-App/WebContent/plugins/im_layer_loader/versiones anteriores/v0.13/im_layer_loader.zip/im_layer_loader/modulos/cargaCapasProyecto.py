from qgis.core import QgsVectorLayer
from qgis.core import QgsProject

from .aplicaciones.aplicaciones import Aplicaciones
from .servicios.geoserverApi import GeoserverApi
from .utilidades.funcionesMapa import FuncionesMapa
from .properties.configProperties import ConfigProperties


class CargaCapasProyecto :

    def __cargarCapasWorkspace(self, aplicacion, userLogin, passLogin, sobreEscribirCapas):
        retorno = ""

        urlGeoserver = ConfigProperties.getPropery("Geoserver", "urlApi")
        urlWFS = ConfigProperties.getPropery("Geoserver", "urlComplementoWFS")

        #INVOCO LA API DE GEOSERVER PARA TRAERME LAS CAPAS DE UN WORKSPACE DETERMINADO
        layers = GeoserverApi.getLayersFromWorkspace(aplicacion, urlGeoserver, userLogin, passLogin)
        if layers is not None:
            vieneMetadataWorkspace = False
            try:
                if len(layers['layers']['layer']) > 0:
                    vieneMetadataWorkspace = True
            except:
                vieneMetadataWorkspace = False
            if vieneMetadataWorkspace:
                cargoAlgunaCapa=False
                for layer in layers['layers']['layer']:
                    nombreCapa = layer['name']
                    capa = aplicacion+":"+nombreCapa
                    wfs_url = urlGeoserver+urlWFS+"&typename="+capa+"&password="+passLogin+"&user="+userLogin
                    # creo la capa
                    layerToLoad = QgsVectorLayer(wfs_url, capa, "WFS")
                    # si la capa es valida la cargo
                    if layerToLoad.isValid():
                        if sobreEscribirCapas:
                            FuncionesMapa.eliminaCapaProyecto(capa)
                        if not FuncionesMapa.existeCapaProyecto(capa):
                            FuncionesMapa.agregarCapaProyecto(layerToLoad)
                            FuncionesMapa.setExpandedCapaProyecto(capa, False)
                            FuncionesMapa.setVisibleCapaProyecto(capa, False)
                        cargoAlgunaCapa = True

                        #UNA VEZ AGREGADA LA CAPA, LE CARGO EL ESTILO DEFINIDO EN GEOSERVER
                        FuncionesMapa.cargarEstiloCapa(aplicacion, nombreCapa, urlGeoserver, userLogin, passLogin)

                        #ACA LLAMARIA AL MODULO DE LAS APLICACIONES
                        Aplicaciones.capasAplicacion(aplicacion, capa)

                    # si la capa no es valida para el usuario anoto el mensaje
                    else:
                        retorno += "\n"+"El usuario " + userLogin + " no puede cargar la capa " + capa
                # si cargue alguna capa, borro el mensaje que venia guardando para no interrumpir el proceso
                if cargoAlgunaCapa:
                    retorno = ""
            else:
                retorno += "\n" + "No se pudo recuperar las capas del workspace " + aplicacion
        else:
            retorno += "\n" + "No se pudo recuperar las capas del workspace " + aplicacion
        return retorno



    def __cargarCapasBase(self, cargaCapaBaseDict):
        FuncionesMapa.eliminarCapasBase(cargaCapaBaseDict)                    
        for capaBase in cargaCapaBaseDict.items():
            capa = capaBase[0]
            seCarga = capaBase[1]
            if seCarga:
                root = QgsProject.instance().layerTreeRoot()
                if not FuncionesMapa.existeGrupo("Mapas base"):
                    grupoCapasBase = root.addGroup("Mapas base") 
                    grupoCapasBase.setIsMutuallyExclusive(True)
                else:
                    grupoCapasBase = root.findGroup("Mapas base")
                FuncionesMapa.agregarCapasBase(capa, grupoCapasBase)
        #PRENDO UNA DE LAS CAPAS ACTIVAS SI ES QUE HAY
        FuncionesMapa.activoCapaBase()

    @staticmethod
    def cargaCapasProyecto(workSpacesSelected, userLogin, passLogin, cargaCapaBaseDict, sobreEscribirCapas):
        retorno=""
        cargaCapas = CargaCapasProyecto()
        cargaCapas.__cargarCapasBase(cargaCapaBaseDict)
        for item in workSpacesSelected:
            workspace = item.text().lower()
            retorno += cargaCapas.__cargarCapasWorkspace(workspace, userLogin, passLogin, sobreEscribirCapas)
        return retorno