from qgis.core import *
from qgis.gui import *

from .serviciosRest import ServiciosRest
from ..utilidades.funcionesGenericas import FuncionesGenericas


class ServiciosCapas :

	@staticmethod
	def obtenerValorCalculado(tabla, nombreUsuario, data, atributo, aplicacion):
		print("busco : " + atributo)
		url = FuncionesGenericas.getUrlServicios(aplicacion)
		responseAtributos = ServiciosRest.invocarRestPost(url+"getCalcFields?tabla="+tabla+"&username="+nombreUsuario, data)
		print(responseAtributos)
		return responseAtributos[atributo]
	
	@staticmethod
	def obtenerAtributosCapa(nombreUsuario, nombreCapa, aplicacion):
		url = FuncionesGenericas.getUrlServicios(aplicacion)
		responseAtributos = ServiciosRest.invocarRestGet(url+"atributocapaformat?username="+nombreUsuario+"&capa="+nombreCapa)
		return responseAtributos

	@staticmethod
	def obtenerCodiguerasData(nombreUsuario, aplicacion):
		url = FuncionesGenericas.getUrlServicios(aplicacion)
		responseCodiguera = ServiciosRest.invocarRestGet(url+"codiguerasdata?username="+nombreUsuario)
		return responseCodiguera

	@qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
	def getCampoDefault(nombreTabla, pk, atributo, nombreUsuario, aplicacion, feature, parent):
		geom = feature.geometry().asWkt()
		data = {'_geometry': geom}
		valuePk = feature.attribute(pk)
		if pk != "" and valuePk is not None:
			if type(valuePk) == int or type(valuePk) == float:
				valuePk = int(valuePk)
			data = {'_geometry': geom, pk: valuePk}
		dato = ServiciosCapas.obtenerValorCalculado(nombreTabla, nombreUsuario, data, atributo, aplicacion)
		return dato