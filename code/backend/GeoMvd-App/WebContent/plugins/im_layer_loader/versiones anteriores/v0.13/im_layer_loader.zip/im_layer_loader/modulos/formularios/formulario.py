from .atributosFormulario import AtributosFormularios
from .codigueras import Codigueras

class Formulario :

	def __configurarAtributo(self, nombreUsuario, nombreCapa, atributosCapa, datosAtributo, aplicacion):
		tipo = ""
		mostrar = False
		soloLectura = False
		requerido = True
		nombreAtributo = ""
		presentation = ""
		valorCalculado = ""
		persistible = False

		if "tipo" in datosAtributo:
		    tipo = datosAtributo["tipo"]
		if "nombre_bd" in datosAtributo:
		    nombreAtributo = datosAtributo["nombre_bd"]
		if "show" in datosAtributo:
		    mostrar = datosAtributo["show"]
		if "read_only" in datosAtributo:
		    soloLectura = datosAtributo["read_only"]	
		if "NILLABLE" in datosAtributo:
		    requerido = not datosAtributo["NILLABLE"]
		if "presentation" in datosAtributo:
		    presentation = datosAtributo["presentation"]
		if "valorCalculado" in datosAtributo:
			valorCalculado = datosAtributo["valorCalculado"]
		if "persistible" in datosAtributo:
			persistible = datosAtributo["persistible"]

		if nombreAtributo != "":
			if mostrar:
				if tipo == "imm.gis.core.feature.ExternalAttribute":
					capaCodiguera = datosAtributo["capa_referenciada"]
					valoresCodiguera = Codigueras.procesarDatosCapaCodiguera(nombreUsuario, capaCodiguera, aplicacion)
					AtributosFormularios.cargaCodigueraAtributo(nombreCapa, nombreAtributo, valoresCodiguera)
				elif tipo == "java.util.Date":
					AtributosFormularios.cargaDateAtributo(nombreCapa, nombreAtributo)
				elif tipo == "java.lang.String" and presentation == "TEXT_AREA":
					AtributosFormularios.cargaTextAreaAtributo(nombreCapa, nombreAtributo)

				if soloLectura:
					AtributosFormularios.atributoSoloLectura(nombreCapa, nombreAtributo)
				if requerido:
					AtributosFormularios.atributoRequerido(nombreCapa, nombreAtributo)
				if valorCalculado != "" and persistible:
					AtributosFormularios.configuraCampoDefault(nombreCapa, atributosCapa, nombreAtributo, persistible, nombreUsuario, aplicacion, tipo)
			else:
				AtributosFormularios.ocultarAtributo(nombreCapa, nombreAtributo)
		elif mostrar and valorCalculado != "" and persistible:
			AtributosFormularios.configuraCampoDefault(nombreCapa, atributosCapa, datosAtributo["nombre"], persistible, nombreUsuario, aplicacion, tipo)
	@staticmethod
	def configurarFormulario(nombreUsuario, nombreCapa, atributosCapa, atributos, aplicacion):
		form = Formulario()
		for clave, valor in atributos.items():
			form.__configurarAtributo(nombreUsuario, nombreCapa, atributosCapa, valor, aplicacion)
		AtributosFormularios.cargarCamposCalculados(nombreUsuario, nombreCapa, atributosCapa, atributos, aplicacion)
