from .serviciosRest import ServiciosRest
import subprocess

class GeoserverApi :

    def getLayersFromWorkspace(aplicacion, urlGeoserver, username, password):
        url = f"{urlGeoserver}/rest/workspaces/{aplicacion}/layers.json"
        result = ServiciosRest.invocarRestGetAuth(url, username, password)
        return result

    def getWorkspacesUser(urlGeoserver, username, password):
        url = f"{urlGeoserver}/rest/workspaces.json"
        result = ServiciosRest.invocarRestGetAuth(url, username, password)
        return result
