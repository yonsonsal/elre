from .configProperties import ConfigProperties
import json

class FuncionesGenericas:

    @staticmethod
    def getUrlServicios(aplicacion):
        url = ConfigProperties.getPropery("ServicioRest", "urlCapas")
        url = url.replace("replaceAppName", aplicacion)
        return url

    @staticmethod
    def convertResultApiToJson(result):
        result_json = result.stdout.decode("utf-8")
        return json.loads(result_json)

    @staticmethod
    def getUserLayer(source):
        substring = "user="
        user = ""
        if substring in source:
            index = source.find(substring)
            user = source[index:].split(' ')[0].split('=')[1].replace('\'', '')
        return user