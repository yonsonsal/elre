import os
import configparser

class ConfigProperties:

	def __cargarProperties(self):  
		thisfolder = os.path.dirname(os.path.abspath(__file__))
		initfile = os.path.join(thisfolder, 'config.properties')
		config = configparser.ConfigParser()
		config.read(initfile)
		return config
	
	@staticmethod
	def getPropery(seccion, propiedad):
		confProp = ConfigProperties()
		prop = confProp.__cargarProperties()
		return prop.get(seccion, propiedad)
