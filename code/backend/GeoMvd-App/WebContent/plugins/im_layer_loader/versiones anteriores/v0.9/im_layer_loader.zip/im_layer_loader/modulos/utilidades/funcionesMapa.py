from qgis.core import QgsCoordinateReferenceSystem
from qgis.core import QgsMapLayerType
from qgis.core import QgsRectangle
from qgis.utils import iface
from qgis.core import QgsProject
from qgis.core import QgsRasterLayer

from .configProperties import ConfigProperties


class FuncionesMapa :
    @staticmethod
    def refrescarZoomCapasCanvas():
        epsg = int(ConfigProperties.getPropery("Configuracion", "epsg"))
        QgsProject.instance().setCrs(QgsCoordinateReferenceSystem(epsg))
        # Get the current map canvas
        canvas = iface.mapCanvas()
        # Get the layer tree root
        root = QgsProject.instance().layerTreeRoot()
        # Get a list of all layers in the layer tree
        layers = root.findLayers()
        # Get the extent of all layers in the layer tree
        extent = QgsRectangle()
        for layer in layers:
            if layer.layer().type() == QgsMapLayerType.VectorLayer:
                extent.combineExtentWith(layer.layer().extent())
        # Zoom to the extent of all layers in the layer tree
        canvas.setExtent(extent)
        # Refresh the map canvas
        canvas.refresh()

    @staticmethod
    def setVisibleCapaProyecto(nombreCapa, visible):
        qgs = QgsProject.instance()
        layer = qgs.mapLayersByName(nombreCapa)[0]
        qgs.layerTreeRoot().findLayer(layer.id()).setItemVisibilityChecked(visible)

    @staticmethod
    def setExpandedCapaProyecto(nombreCapa, expand):
        qgs = QgsProject.instance()
        layer = qgs.mapLayersByName(nombreCapa)[0]
        qgs.layerTreeRoot().findLayer(layer.id()).setExpanded(expand)

    @staticmethod
    def existeCapaProyecto(nombreCapa):
        qgs = QgsProject.instance()
        layers = qgs.mapLayersByName(nombreCapa)
        exist = True if layers else False
        return exist
    
    @staticmethod
    def eliminaCapaProyecto(nombreCapa):
        qgs = QgsProject.instance()
        layers = qgs.mapLayersByName(nombreCapa)
        exist = True if layers else False
        if exist:
            layer = layers[0]
            qgs.removeMapLayers([layer.id()])

    @staticmethod
    def agregarCapaProyecto(layer):
        qgs = QgsProject.instance()
        qgs.addMapLayer(layer)

    @staticmethod
    def agregarCapaProyectoAGrupo(layer, grupo):
        qgs = QgsProject.instance()
        qgs.addMapLayer(layer, False)
        grupo.addLayer(layer)

    @staticmethod
    def agregarCapasBase(capa, grupo):
        url = ConfigProperties.getPropery("CapasBase", "url"+capa)
        nombreCapa = ConfigProperties.getPropery("CapasBase", "nombre"+capa)
        if not FuncionesMapa.existeCapaProyecto(nombreCapa):
            FuncionesMapa.cargaRasterLayerEnGrupo(url, nombreCapa, grupo)

    @staticmethod
    def eliminarCapasBase(cargaCapaBaseDict):        
        for capaBase in cargaCapaBaseDict.items():
            capa = capaBase[0]
            nombreCapa = ConfigProperties.getPropery("CapasBase", "nombre"+capa)
            FuncionesMapa.eliminaCapaProyecto(nombreCapa)
        root = QgsProject.instance().layerTreeRoot()
        for group in [child for child in root.children() if child.nodeType() == 0]:
            if group.name() == 'Mapas base':
                root.removeChildNode(group)

    @staticmethod
    def activoCapaBase():
        #VOY A ESTABLECER UN ORDEN DE IMPORTANCIA PARA SABER CUAL CAPA BASE
        #PRENDO EN CASO DE QUE HAYA MAS DE UNA

        nombreCapaIM = ConfigProperties.getPropery("CapasBase", "nombreCapaBaseIM")
        nombreCapaOSM = ConfigProperties.getPropery("CapasBase", "nombreCapaOSM")
        nombreCapaIDE = ConfigProperties.getPropery("CapasBase", "nombreCapaIde")

        if FuncionesMapa.existeCapaProyecto(nombreCapaIM):
            FuncionesMapa.setVisibleCapaProyecto(nombreCapaIM, True)
        elif FuncionesMapa.existeCapaProyecto(nombreCapaOSM):
            FuncionesMapa.setVisibleCapaProyecto(nombreCapaOSM, True)
        elif FuncionesMapa.existeCapaProyecto(nombreCapaIDE):
            FuncionesMapa.setVisibleCapaProyecto(nombreCapaIDE, True)

    @staticmethod
    def cargaRasterLayer(url, nombreCapa):
        layer = QgsRasterLayer(url, nombreCapa, 'wms')
        if layer.isValid():
            FuncionesMapa.agregarCapaProyecto(layer)
            FuncionesMapa.setExpandedCapaProyecto(nombreCapa, False)
            FuncionesMapa.setVisibleCapaProyecto(nombreCapa, False)
        else:
            print("No se pudo cargar la capa: " + nombreCapa)
    
    @staticmethod
    def cargaRasterLayerEnGrupo(url, nombreCapa, grupo):
        layer = QgsRasterLayer(url, nombreCapa, 'wms')
        if layer.isValid():
            FuncionesMapa.agregarCapaProyectoAGrupo(layer, grupo)
            FuncionesMapa.setExpandedCapaProyecto(nombreCapa, False)
            FuncionesMapa.setVisibleCapaProyecto(nombreCapa, False)
        else:
            print("No se pudo cargar la capa: " + nombreCapa)