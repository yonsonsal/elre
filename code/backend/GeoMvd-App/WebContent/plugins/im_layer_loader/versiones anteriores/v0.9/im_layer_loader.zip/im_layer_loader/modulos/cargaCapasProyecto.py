from qgis.core import QgsVectorLayer
from qgis.core import QgsProject

from .servicios.geoserverApi import GeoserverApi
from .utilidades.funcionesMapa import FuncionesMapa
from .utilidades.configProperties import ConfigProperties


class CargaCapasProyecto :

    def __cargarCapasWorkspace(self, aplicacion, userLogin, passLogin, sobreEscribirCapas):
        retorno = ""

        urlGeoserver = ConfigProperties.getPropery("Geoserver", "urlApi")
        urlWFS = ConfigProperties.getPropery("Geoserver", "urlComplementoWFS")

        #INVOCO LA API DE GEOSERVER PARA TRAERME LAS CAPAS DE UN WORKSPACE DETERMINADO
        layers = GeoserverApi.getLayersFromWorkspace(aplicacion, urlGeoserver, userLogin, passLogin)
        if layers is not None:
            vieneMetadataWorkspace = False
            try:
                if len(layers['layers']['layer']) > 0:
                    vieneMetadataWorkspace = True
            except:
                vieneMetadataWorkspace = False
            if vieneMetadataWorkspace:
                cargoAlgunaCapa=False
                for layer in layers['layers']['layer']:
                    nombreCapa = layer['name']
                    capa = aplicacion+":"+nombreCapa
                    wfs_url = urlGeoserver+urlWFS+"&typename="+capa+"&password="+passLogin+"&user="+userLogin
                    # creo la capa
                    layerToLoad = QgsVectorLayer(wfs_url, capa, "WFS")
                    # si la capa es valida la cargo
                    if layerToLoad.isValid():
                        if sobreEscribirCapas :
                            FuncionesMapa.eliminaCapaProyecto(capa)
                            FuncionesMapa.agregarCapaProyecto(layerToLoad)
                        elif not FuncionesMapa.existeCapaProyecto(capa):
                            FuncionesMapa.agregarCapaProyecto(layerToLoad)
                        cargoAlgunaCapa=True
                    # si la capa no es valida para el usuario anoto el mensaje
                    else:
                        retorno += "\n"+"El usuario " + userLogin + " no puede cargar la capa " + capa
                # si cargue alguna capa, borro el mensaje que venia guardando para no interrumpir el proceso
                if cargoAlgunaCapa:
                    retorno = ""
            else:
                retorno += "\n" + "No se pudo recuperar las capas del workspace " + aplicacion
        else:
            retorno += "\n" + "No se pudo recuperar las capas del workspace " + aplicacion
        return retorno



    def __cargarCapasBase(self, cargaCapaBaseDict, sobreEscribirCapas):

        #SI ESTA MARCADA LA OPCION DE SOBRE ESCRIBIR YA BORRO
        #TODAS LAS CAPAS BASES QUE EXISTAN
        if sobreEscribirCapas:
            FuncionesMapa.eliminarCapasBase(cargaCapaBaseDict)

        #RECORRO LAS CAPAS BASE SELECCIONADAS DISPONIBLES
        #AGREGO SOLO LAS SELECCIONADAS
        
        root = QgsProject.instance().layerTreeRoot()
        grupoCapasBase = root.addGroup("Mapas base") 
        grupoCapasBase.setIsMutuallyExclusive(True)              
        for capaBase in cargaCapaBaseDict.items():
            capa = capaBase[0]
            seCarga = capaBase[1]
            if seCarga:
                FuncionesMapa.agregarCapasBase(capa, grupoCapasBase)

        #PRENDO UNA DE LAS CAPAS ACTIVAS SI ES QUE HAY
        FuncionesMapa.activoCapaBase()

    @staticmethod
    def cargaCapasProyecto(workSpacesSelected, userLogin, passLogin, cargaCapaBaseDict, sobreEscribirCapas):
        retorno=""
        cargaCapas = CargaCapasProyecto()
        cargaCapas.__cargarCapasBase(cargaCapaBaseDict, sobreEscribirCapas)
        for item in workSpacesSelected:
            workspace = item.text().lower()
            retorno += cargaCapas.__cargarCapasWorkspace(workspace, userLogin, passLogin, sobreEscribirCapas)
        return retorno