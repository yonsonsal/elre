from qgis.core import QgsProject
from qgis.core import QgsAction
from ..utilidades.configProperties import ConfigProperties
from ..utilidades.funcionesGenericas import FuncionesGenericas


class CamposCalculados:

	@staticmethod
	def cargarCamposCalculados(nombreUsuario, nombreCapa, atributosCapa, atributosFormulario, aplicacion):
		
		diccionarioCamposCalculados = dict()
		for clave, valor in atributosFormulario.items():
			valorCalculado = ""
			mostrar = False
			if "valorCalculado" in valor:
			    valorCalculado = valor["valorCalculado"]
			if "show" in valor:
			    mostrar = valor["show"]
			if valorCalculado != "" and mostrar:
				diccionarioCamposCalculados[valor["nombre"]]=valor["label"]	
				
		cantidadCamposCalculados = len(diccionarioCamposCalculados)
		
		if cantidadCamposCalculados > 0:
			url = FuncionesGenericas.getUrlServicios(aplicacion)
			nombreActionCamposCalculados = ConfigProperties.getPropery("Actions", "nombreActionCamposCalculados")
			nombreCortoActionCamposCalculados = ConfigProperties.getPropery("Actions", "nombreCortoActionCamposCalculados")
			layer = QgsProject.instance().mapLayersByName(nombreCapa)[0]
			
			actionManager = layer.actions()
			actions = actionManager.actions()
			if len(actions) > 0:
				for a in actions:
					if a.name() == nombreActionCamposCalculados:
						layer.actions().removeAction(a.id())
			
			nombreTabla = atributosCapa['nombreTabla']
			pk = atributosCapa['pk']
			comilla = "'"
			dobleComilla = '"'
			mas = "+"
			abre = comilla + dobleComilla + comilla + mas
			cierra = mas + comilla + dobleComilla + comilla
			text_comand = "from qgis.utils import iface"
			text_comand += "\nfrom qgis.PyQt import QtWidgets"
			text_comand += "\nimport requests"
			text_comand += "\nimport json"
			text_comand += "\n"
			text_comand += "\npry=QgsProject.instance()"
			text_comand += "\nurl = '" + url + "'"
			text_comand += "\n"
			text_comand += "\nlayer = iface.activeLayer()"
			text_comand += "\nuser = layer.source().split(' ')[0].split('=')[1].replace('\\'','') "
			text_comand += "\ngeom = [% "+abre+" geom_to_wkt(  $geometry, 10 ) "+cierra+" %]"
			text_comand += "\n"
			text_comand += "\nnombreTabla = '" + nombreTabla +"'"
			text_comand += "\n"
			text_comand += "\nheaders = {'Accept': 'application/json'}"
			text_comand += "\n"
			text_comand += "\ndata = {'_geometry': geom}"
			text_comand += '\nif str([%  '+dobleComilla+pk+dobleComilla+'  %]) != '+dobleComilla+dobleComilla+' : '
			text_comand += "\n	data = {'"+pk+"' : ([%  "+dobleComilla+pk+dobleComilla+"  %]), '_geometry': geom}"
			text_comand += "\nurlPost = url+'getCalcFields?tabla='+nombreTabla+'&username='+user"
			text_comand += "\nresponse = requests.post(urlPost, json=data, verify=False, headers=headers)"
			text_comand += "\ncamposCalculados = response.json()"
			text_comand += "\n"
			text_comand += "\nQtWidgets.QMessageBox.information(None, 'Campos Calculados', "
			i = 1
			for nombre, etiqueta in diccionarioCamposCalculados.items():
		    		if i == cantidadCamposCalculados:
		    			text_comand += "\n'"+etiqueta+": ' + camposCalculados['"+nombre+"']"
		    		else:
		    			text_comand += "\n'"+etiqueta+": ' + camposCalculados['"+nombre+"'] + '\\n' + "
		    		i=i+1
			text_comand += "\n)"

			camposCalculadosAction = QgsAction(1, 
					    nombreActionCamposCalculados, 
					    text_comand, 
					    None, 
					    capture=False, 
					    shortTitle=nombreCortoActionCamposCalculados, 
					    actionScopes={'Layer', 'Form', 'Canvas', 'Field', 'Feature'}
					    )
			layer.actions().addAction(camposCalculadosAction)
