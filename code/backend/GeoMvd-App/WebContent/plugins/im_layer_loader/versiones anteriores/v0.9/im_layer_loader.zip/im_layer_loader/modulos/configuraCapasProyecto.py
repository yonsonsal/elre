from qgis.core import QgsMapLayerType
from qgis.core import QgsProject
from qgis.utils import iface
from .servicios.serviciosCapas import ServiciosCapas
from .formularios.formulario import Formulario
from .formularios.camposCalculados import CamposCalculados
from .utilidades.configProperties import ConfigProperties
from .utilidades.funcionesGenericas import FuncionesGenericas


class ConfiguraCapasProyecto :

	def __procesarDatosCapa(self, nombreUsuario, nombreCapa, aplicacion):
		retorno = ""
		cargaCampCalc  = ConfigProperties.getPropery("Configuracion", "cargaCamposCalculados")
		atributosCapa = ServiciosCapas.obtenerAtributosCapa(nombreUsuario, nombreCapa, aplicacion)
		if atributosCapa is not None:
			esCodiguera = atributosCapa["esCodiguera"]
			atributosFormulario = atributosCapa["atributos"]
			if not esCodiguera :
				Formulario.configurarFormulario(nombreUsuario, nombreCapa, atributosFormulario, aplicacion)
				if cargaCampCalc == "S":
					CamposCalculados.cargarCamposCalculados(nombreUsuario, nombreCapa, atributosCapa, atributosFormulario, aplicacion)
				retorno = "Se Configuró Correctamente La Capa: " + nombreCapa
		else:
			retorno = "No Existe Metadata De La Capa: " + nombreCapa
		
		return retorno

	@staticmethod
	def configuraCapaActiva(aplicacion):
		retorno = ""
		layer = iface.activeLayer()
		if layer is not None:
			if layer.type() == QgsMapLayerType.VectorLayer and len(layer.name().split(":")) > 1:
				workspace = ""
				layername = ""
				if len(layer.name().split(":")) > 1:
					workspace = layer.name().split(":")[0]
					layername = layer.name().split(":")[1]
					layer.setName(layername)
				nombreUsuario = FuncionesGenericas.getUserLayer(layer.source())
				nombreCapa = layer.name()
				conf = ConfiguraCapasProyecto()
				retorno = conf.__procesarDatosCapa(nombreUsuario, nombreCapa, aplicacion)
				if workspace != "":
					layer.setName(workspace+":"+layername)
			else:
				retorno = "La Capa Activa no es configurable"
		else:
			retorno = "No Existe Capa Activa"
		return retorno

	@staticmethod
	def configuraCapasProyecto(aplicacion):
		retorno = ""
		if len(QgsProject.instance().mapLayers().values()) > 0:
			for layer in QgsProject.instance().mapLayers().values():
				if layer.type() == QgsMapLayerType.VectorLayer and len(layer.name().split(":")) > 1:
					workspace = ""
					layername = ""
					if len(layer.name().split(":")) > 1:
						workspace = layer.name().split(":")[0]
						layername = layer.name().split(":")[1]
						layer.setName(layername)
					nombreUsuario = FuncionesGenericas.getUserLayer(layer.source())
					nombreCapa = layer.name()
					conf = ConfiguraCapasProyecto()
					retorno += "\n"+conf.__procesarDatosCapa(nombreUsuario, nombreCapa, aplicacion)
					if workspace != "":
						layer.setName(workspace+":"+layername)
		else:
			retorno = "No Existen Capas Agregadas"
		return retorno
