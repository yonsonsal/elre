from .configProperties import ConfigProperties
import json

class FuncionesGenericas:

    @staticmethod
    def getUrlServicios(aplicacion):
        url = ConfigProperties.getPropery("ServicioRest", "urlCapas")
        url = url.replace("replaceAppName", aplicacion)
        return url

    @staticmethod
    def getUserLayer(source):
        substring = "user="
        user = ""
        if substring in source:
            index = source.find(substring)
            user = source[index:].split(' ')[0].split('=')[1].replace('\'', '')
        return user

    @staticmethod
    def getLayerName(nombreCapaCompleto):
        return nombreCapaCompleto.split(":")