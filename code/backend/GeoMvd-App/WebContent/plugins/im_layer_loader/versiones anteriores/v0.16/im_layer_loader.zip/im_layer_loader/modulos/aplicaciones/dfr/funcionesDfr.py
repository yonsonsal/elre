from qgis.PyQt import QtWidgets
from qgis.core import *
from qgis.gui import *

from PyQt5.QtWidgets import QProgressDialog
from qgis.utils import iface

from .auxiliaresDfr import AuxiliaresDfr
from .calculadora_de_posiciones import CalculadoraDePosiciones


class FuncionesDfr:

    @staticmethod
    def disponibilizarFuncionesParaExpresiones():
        # Create a function factory and register the functions
        factory = QgsExpression()
        factory.registerFunction(FuncionesDfr.calcularPosicionDfr)
        factory.registerFunction(FuncionesDfr.getRegionDfr)
        factory.registerFunction(FuncionesDfr.getTipoPuntoLevanteDfr)

    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getRegionDfr(feature, parent):
        regionActual = feature.attribute("REGION")
        region = 1 #Region Este
        if regionActual is not None:
            region = regionActual
        return region

    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getTipoPuntoLevanteDfr(feature, parent):
        tplActual= feature.attribute("TIPO_PUNTO_LEVANTE")
        tpl = 1 #CL
        if tplActual is not None:
            tpl = tplActual
        return tpl

    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def calcularPosicionDfr(feature, parent):
        nombreCapaPosicionesRecorrido = "dfr:E_DF_POSICIONES_RECORRIDO"
        nombreCapaRutasRecorrido = "dfr:E_DF_RUTAS_RECORRIDO"
        codRecorrido = feature.attribute("COD_RECORRIDO")
        posicionActual = feature.attribute("POSICION")

        geom = feature.geometry().asWkt()
        qgs_geom = QgsGeometry.fromWkt(geom)
        qgs_point = qgs_geom.asPoint()
        qgs_point_xy = QgsPointXY(qgs_point)
        posicion = 0
        if posicionActual is not None:
            posicion = int(posicionActual)
        else:
            try:
                calculadora = CalculadoraDePosiciones()
                posicion = 1#calculadora.calcularPosicion(nombreCapaPosicionesRecorrido, nombreCapaRutasRecorrido, codRecorrido, qgs_point_xy )
            except:
                posicion = NULL
        return posicion

    @staticmethod
    def despuesAgregarPosicionesRecorrido(featureId):
        layerName="dfr:E_DF_POSICIONES_RECORRIDO"
        layer = QgsProject.instance().mapLayersByName(layerName)[0]
        feature = layer.getFeature(featureId)

        feature = AuxiliaresDfr.inicializoAtributosPosicionesRecorrido(feature)

        layer.updateFeature(feature)
        layer.triggerRepaint()

        #aca habria que llamar a la funcion que renumera
        reordenado = False
        try:
            posicionNueva = 0
            if feature.attribute("POSICION") is not None:
                posicionNueva = int(feature.attribute("POSICION"))
                codRecorrido = feature.attribute("COD_RECORRIDO")
                calculadora = CalculadoraDePosiciones()
                reordenado = True#calculadora.reordenarPuntosAlta(layerName, posicionNueva)
        except:
            reordenado = False

        if not reordenado:
            QtWidgets.QMessageBox.information(None, "Proceso Alta Posicion Recorrido", "Se produjo un error al ordenar el recorrido")
