from qgis.core import QgsProject

from .funcionesDfr import FuncionesDfr
from ...utilidades.funcionesGenericas import FuncionesGenericas


class Dfr:

    @staticmethod
    def procesarAplicacion(*args):

        FuncionesDfr.disponibilizarFuncionesParaExpresiones()

        workspace = args[0]
        layerName = args[1]

        if layerName == "dfr:E_DF_POSICIONES_RECORRIDO":
            layer = QgsProject.instance().mapLayersByName(layerName)[0]
            layer.featureAdded.connect(FuncionesDfr.despuesAgregarPosicionesRecorrido)



