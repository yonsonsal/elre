from PyQt5.QtWidgets import QInputDialog
from qgis.PyQt import QtWidgets
from qgis.core import QgsProject
from qgis.utils import iface
class AuxiliaresDfr:

    @staticmethod
    def inicializoAtributosPosicionesRecorrido(feature):
        feature.setAttribute("ULTIMA_POSICION", 0)
        return feature