import time
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, QVariant
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction
from qgis.core import Qgis, QgsPointXY, QgsMapLayerType, QgsGeometry, QgsProject, QgsFeature, QgsVectorLayer, QgsField, QgsLineString, QgsFeatureRequest, QgsExpression

from qgis.analysis import *

from qgis.core import (QgsProcessing,
                       QgsProcessingAlgorithm,
                       QgsProcessingException,
                       QgsProcessingOutputNumber,
                       QgsProcessingParameterDistance,
                       QgsProcessingParameterFeatureSource,
                       QgsProcessingParameterVectorDestination,
                       QgsProcessingParameterRasterDestination)

from qgis import processing




class CalculadoraDePosiciones:


    #########################################################

    def auxiliarVerFeature(self, nombre_capa, tipo, feat, visible):
        capaAuxiliar = QgsVectorLayer(tipo + "?crs=EPSG:32721", nombre_capa, "memory")
        provider = capaAuxiliar.dataProvider()

        feature = QgsFeature()
        feature.setGeometry(feat.geometry())
        provider.addFeatures([feature])
        QgsProject.instance().addMapLayer(capaAuxiliar, visible)

    #########################################################

    def auxiliarVerGeometria(self, nombre_capa, tipo, geometria, visible):
        capaAuxiliar = QgsVectorLayer(tipo + "?crs=EPSG:32721", nombre_capa, "memory")
        provider = capaAuxiliar.dataProvider()

        feature = QgsFeature()
        feature.setGeometry(geometria)
        provider.addFeatures([feature])

        return capaAuxiliar

    #########################################################
    
    def limpiarCapasEnMemoria(self):
        for layer in QgsProject.instance().mapLayers().values():
            # Comprobar si la capa es una capa en memoria
            if layer.type() == QgsMapLayerType.VectorLayer and layer.dataProvider().name() == 'memory':
                # Quitar la capa del proyecto
                QgsProject.instance().removeMapLayer(layer)

    #########################################################

    def eliminarCapaEnMemoria(self, nombre_capa):
        try:
            layer = QgsProject.instance().mapLayersByName(nombre_capa)[0]
            # Remover la capa del proyecto
            QgsProject.instance().removeMapLayer(layer.id())
        except IndexError:
            pass #no borro nada

    #########################################################

    def verCapasEnMemory(self):
        print("Hay capas")
        print("Hay capas en memoria -> ", QgsProject.instance().mapLayers().values())
        capas_memoria = [capa for capa in QgsProject.instance().mapLayers().values() if capa.dataProvider().name() == 'memory']
        for capa in capas_memoria:
            print(capa.name())
        print("Si hay capas se imprimieros")

    #########################################################

    def obtenerFeatureDeCapaPorAtr(self, capa, atr, atr_valor):

        layer = QgsProject.instance().mapLayersByName(capa)[0]
        #for feture in layer_befferPorSeg.getFeatures():
        field_name = atr  # Nombre del atributo a filtrar
        field_value = atr_valor         
        
        expPos = QgsExpression(f"{field_name} = '{field_value}'")
        request = QgsFeatureRequest(expPos)
        for feature in layer.getFeatures(request):
            return feature        

    #########################################################

    def crearVerticesDeUnRecorrido(self):
        self.cap_vertices = QgsVectorLayer("Point?crs=EPSG:32721", "Vertices", "memory")

        field = QgsField("ID", QVariant.Int)
        self.cap_vertices.dataProvider().addAttributes([field])
        self.cap_vertices.updateFields()

        lin = self.obtenerFeatureDeCapaPorAtr(self.CapaRecorridoVigente, "NOM_RUT", self.nom_rut)

        for i, vertex in enumerate(lin.geometry().asPolyline()):
            feature = QgsFeature()
            point = QgsPointXY(vertex.x(), vertex.y())
            feature.setGeometry(QgsGeometry.fromPointXY(point))
            feature.setAttributes([i])
            self.cap_vertices.dataProvider().addFeatures([feature])

    #########################################################

    def crearSegmentosConVertices(self):

        layerVer = self.cap_vertices

        self.cap_segmentosV = QgsVectorLayer("LineString?crs=EPSG:32721", "SegmentosV", "memory")
        provider = self.cap_segmentosV.dataProvider()
        field = QgsField("ID", QVariant.Int)
        provider.addAttributes([field])
        self.cap_segmentosV.updateFields()
        
        featuresV = [f for f in layerVer.getFeatures()]

        # Ordena la lista de características por un atributo
        featuresV.sort(key=lambda x: x.attribute("ID"))
        point1 = QgsFeature()
        point2 = QgsFeature()
        
        for i, featureV in enumerate(featuresV):        
            #print("El número es ", i)
            if i == 0:
                #print("El número es par")
                point1 = QgsFeature(featureV)
            else:
                #print("El número es impar")
                point2 = QgsFeature(featureV)
                seg = QgsGeometry.fromPolylineXY([point1.geometry().asPoint(), point2.geometry().asPoint()])
                featS = QgsFeature()        
                featS.setGeometry(seg)
                featS.setAttributes([i-1])
                provider.addFeatures([featS])
                point1 = point2
            self.cantidadDeSegmentosV = i     


    #########################################################

    def proyectarPosicionesARecorrido(self):

        layerRecorrido = QgsProject.instance().mapLayersByName(self.CapaRecorridoVigente)[0]
        
        layerProyectados = QgsVectorLayer("Point?crs=EPSG:32721", "PosicionesProyectadas", "memory")
        

        provider = layerProyectados.dataProvider()
        field_ID = QgsField("ID", QVariant.Int)
        field_SEG = QgsField("ID_SEGMENTO", QVariant.Int)
        provider.addAttributes([field_ID, field_SEG])
        layerProyectados.updateFields()

        layerPosiciones = QgsProject.instance().mapLayersByName(self.CapaPosicionesVigentes)[0]
    
        recorrido = next(layerRecorrido.getFeatures())
        geomlinea = recorrido.geometry()

        for featurePos in layerPosiciones.getFeatures():                

                feat = QgsFeature()

                distance, closest_point, before_vertex, after_vertex = geomlinea.closestSegmentWithContext(featurePos.geometry().asPoint())
                feat.setGeometry(QgsGeometry.fromPointXY(closest_point))
                feat.setAttributes([featurePos["POSICION"], before_vertex-1])
                provider.addFeatures([feat])
                
        
        QgsProject.instance().addMapLayer(layerProyectados, self.verCapasEnMemoria) 

    
    #########################################################

    def detectorPosicionesMal(self):
        cont = 0
        flag = True
        dicc_pos_geomRec = {}
        while flag and cont < self.vueltas:
            lisPos_dicPosSeg = self.obtenerListaPosicionesDicSegRec()   #retorna [lista de posiciones proyectadas, dicc {Pos:id Segmento}]
            l = lisPos_dicPosSeg[0]
            print("l:", l)
            d = lisPos_dicPosSeg[1]
            listaNegra = self.obtenerListaPoscionesMal(l)
            print ("MAL:", listaNegra)
            print("d:", d)
            print("Pasada :", cont)

            dicc_pos_geomRec = self.corregirListaNegra(listaNegra, d, dicc_pos_geomRec)

            if len(listaNegra) == 0:
                flag = False
            cont = cont + 1


    #########################################################

    def obtenerListaPosicionesDicSegRec(self):
        layerPosicion = QgsProject.instance().mapLayersByName("PosicionesProyectadas")[0] 

        # Imprimir la lista de características ordenadas
        fueraRango = []
        listaPosiciones = []
        diccSegRec = dict()

        for segmento in range(self.cantidadDeSegmentosV):

            expPos = QgsExpression(f"ID_SEGMENTO = '{segmento}'")
            
            requestPos = QgsFeatureRequest(expPos).setFlags(QgsFeatureRequest.NoGeometry).setSubsetOfAttributes(['ID', 'ID_SEGMENTO'], layerPosicion.fields() )
            featuresPs = layerPosicion.getFeatures(requestPos)
            
            layer_sorted_posicion = sorted(featuresPs , key=lambda x: x['ID'])
            for featurePos in layer_sorted_posicion:
                      
                listaPosiciones.append(featurePos['ID'])
                
                diccSegRec[featurePos['ID']] = featurePos['ID_SEGMENTO']
        
        return (listaPosiciones, diccSegRec)   
        

    #########################################################

    def obtenerListaPoscionesMal (self,pts):
        
        maxpos = (QgsProject.instance().mapLayersByName(self.CapaPosicionesVigentes)[0]).featureCount() 
        p = 0
        s = 0
        p_ = 0
        s_ = 0
        
        rotos = []
        
        serie = list(range(1, maxpos+1))
        
        while (p < maxpos) and (s  < maxpos):

            p_ = pts[p]
            s_ = serie[s]
            
            if p_ == s_:

                p = p + 1
                s = s + 1
            elif serie[s] in rotos:

                s = s + 1
            elif pts[p] == serie[s+1] : #falta uno

                rotos.append(serie[s])
                s = s + 2
                p = p + 1
            elif pts[p+1] ==  pts[p]+1 and (pts[p+2] ==  pts[p]+2):
                rotos.append(serie[s])
                s = s +1
            else:  

                if not (p_ in rotos):
                    rotos.append(pts[p])
                p = p +1
        
            
        return (rotos)    

    #########################################################

    def corregirListaNegra(self, listaNegra, dicc_PosSeg, dicc_pos_geomRec):

        for idPos in listaNegra:

            segmentoPos = dicc_PosSeg[idPos]

            dicc_pos_geomRec[idPos] = self.corregirPos(idPos, segmentoPos, dicc_pos_geomRec)    

        return dicc_pos_geomRec
    
    #########################################################    
            
    def corregirPos(self, pos, idSegmento, dicc_pos_geomRec):

        layerPosiciones = QgsProject.instance().mapLayersByName(self.CapaPosicionesVigentes)[0]
        layerPtsProyectados = QgsProject.instance().mapLayersByName("PosicionesProyectadas")[0]
        
        expPos = QgsExpression(f'"POSICION" = {pos} ')
        requestPos = QgsFeatureRequest(expPos)

        featuresPos = layerPosiciones.getFeatures(requestPos)       

        puntoAProyectar = next(featuresPos)

        if pos in dicc_pos_geomRec:
 
            capas_segmentosUnidos_segmentosSeparados = self.quitarTramoId(idSegmento, dicc_pos_geomRec[pos])
        else:

            dicc_pos_geomRec[pos] = self.cap_segmentosV.clone()
            capas_segmentosUnidos_segmentosSeparados = self.quitarTramoId(idSegmento, dicc_pos_geomRec[pos])


        capa_segmentosUnidos = capas_segmentosUnidos_segmentosSeparados[0]
        capa_segmentosSeparados = capas_segmentosUnidos_segmentosSeparados[1]

        dicc_pos_geomRec[pos] = capa_segmentosSeparados
 
        recorridoAmputado = next(capa_segmentosUnidos.getFeatures())
        
        distance, closest_point, before_vertex, after_vertex = recorridoAmputado.geometry().closestSegmentWithContext(puntoAProyectar.geometry().asPoint())

        expProy = QgsExpression(f'"ID" = {pos}')
        requestProy = QgsFeatureRequest(expProy)

        featuresPosProy = layerPtsProyectados.getFeatures(requestProy)
        puntoProyectado = next(featuresPosProy)

        geomNueva = QgsGeometry.fromPointXY(closest_point)

        layerPtsProyectados.dataProvider().changeGeometryValues({ puntoProyectado.id() : geomNueva })
        
        feat = QgsFeature()
        feat.setGeometry(QgsGeometry.fromPointXY(closest_point))
        segmento = self.obtenerSegmentoRecorrdioPorPuntoCercanoCapaSV(feat, capa_segmentosSeparados)
        field_idx_seg = layerPtsProyectados.fields().indexOf('ID_SEGMENTO')
        
        layerPtsProyectados.dataProvider().changeAttributeValues({puntoProyectado.id(): {field_idx_seg: segmento["ID"]} })
          
        return dicc_pos_geomRec[pos]
    
    #########################################################

    def quitarTramoId(self, idSegmento, layer_segmentos_copia):  
    
        layer_segmentos_copia = self.eliminarEntidad(layer_segmentos_copia, "ID", idSegmento)

        return (self.unirCapa(layer_segmentos_copia, idSegmento), layer_segmentos_copia)  #-->retorna "LaMasUnida"
    
    #########################################################

    def eliminarEntidad(self, capa, atributo, idEliminar):

        expPos = QgsExpression(f'{atributo} = {idEliminar} ')
    
        requestPos = QgsFeatureRequest(expPos).setFlags(QgsFeatureRequest.NoGeometry)

        featuresPos = capa.getFeatures(requestPos) 
        feature = next(featuresPos)

        capa.dataProvider().deleteFeatures([feature.id()])

        return capa    

    #########################################################

    def unirCapa(self, capa, idSegmento):
        geometrias = [f.geometry() for f in capa.getFeatures()]

        # Creamos una nueva geometría que es la unión de todas las geometrías de la capa
        geometria_union = QgsGeometry.unaryUnion(geometrias)

        # Creamos una nueva capa con una sola entidad que representa la unión de todas las geometrías
        #capa_union = QgsVectorLayer("Polygon?crs=EPSG:4326", "Unión", "memory")
        
        return self.auxiliarVerGeometria("LaMasUnida" + str(idSegmento), "LineString", geometria_union, self.verCapasEnMemoria)

    #########################################################

    def obtenerSegmentoRecorrdioPorPuntoCercanoCapaSV(self, punto, layer_Segmentos):


        for feature in layer_Segmentos.getFeatures():

            if punto.geometry().buffer(0.01, 8).intersects(feature.geometry()):

                self.auxiliarVerGeometria("bufferAlpto", "Polygon", punto.geometry().buffer(0.01, 8), self.verCapasEnMemoria)
                return feature

    #########################################################

    def proyectarPtoNuevoEnRecorrido(self, capa_recorridos):

        feat_pto_nuevo = QgsFeature()
  
        feature = self.puntoNuevo
                    
        feat_pto_nuevo.setGeometry(feature.geometry())

        recorridos = QgsProject.instance().mapLayersByName(capa_recorridos)[0]
        recorrido = next(recorridos.getFeatures())

        self.capaPtoCerca = QgsVectorLayer("Point?crs=EPSG:32721", "PtoCerca", "memory")
        provider = self.capaPtoCerca.dataProvider()
        feat = QgsFeature()

        geomlinea = recorrido.geometry()
 
        gl = QgsGeometry(geomlinea)

        distance, closest_point, before_vertex, after_vertex = gl.closestSegmentWithContext(feature.geometry().asPoint())
        feat.setGeometry(QgsGeometry.fromPointXY(closest_point))
        provider.addFeatures([feat])


        line = QgsLineString([feat.geometry().asPoint(), feat_pto_nuevo.geometry().asPoint()])
        geometry = QgsGeometry.fromPolyline(line)

        layseg = QgsVectorLayer("LineString?crs=EPSG:32721", "segmento", "memory")
        providerSeg = layseg.dataProvider()

        featSeg = QgsFeature()
        featSeg.setGeometry(geometry)
        providerSeg.addFeatures([featSeg])

        QgsProject.instance().addMapLayer(layseg, self.verCapasEnMemoria)

        params = {
            'INPUT': 'segmento',
            'OUTPUT': 'memory:',
            'START_DISTANCE': 0.01,  # longitud de la extensión en unidades del sistema de coordenadas de la capa
            'END_DISTANCE': 0,
            'OUTPUT_TYPE': 0,  # tipo de capa de salida: 0 (misma geometría que la capa de entrada)
        }

        result = processing.run('qgis:extendlines', params)

        # Verifica que el geoproceso se haya ejecutado correctamente
        if result['OUTPUT']:
            
            layer_extended = result['OUTPUT']

            QgsProject.instance().addMapLayer(layer_extended, self.verCapasEnMemoria)
            

    #########################################################
    def obtenerPosicionNuevo(self):
        subSegmentos_idSeg  = self.obtenerCapaSgmentoDividido_idSegmento()
        
        layerSubSegmentos = subSegmentos_idSeg[0]
        idSegmento = subSegmentos_idSeg[1]
        vertice0 = subSegmentos_idSeg[2]
        vertice1 = subSegmentos_idSeg[3]
        ptoCerca = subSegmentos_idSeg[4]

        puntos_contenidosA = []
        puntos_contenidosB = []
        
        yaInicializoFlagA = False
        flagA = True

        if  layerSubSegmentos.featureCount() == 1: # el ptoNuevo esta en un extremo del segmento
            
            if (ptoCerca.geometry().distance(QgsGeometry.fromPointXY(QgsPointXY(vertice0))) < 
                ptoCerca.geometry().distance(QgsGeometry.fromPointXY(QgsPointXY(vertice1)))):
                print("estoy en A")
                flagA = False
            else:
                flagA = True
                print("estoy en B")

            yaInicializoFlagA = True

        for i, featSubSegmento in enumerate(layerSubSegmentos.getFeatures()):
            
            if not yaInicializoFlagA:
                if  featSubSegmento.geometry().intersects((QgsGeometry.fromPointXY(QgsPointXY(vertice0)).buffer(0.01, 15))): 
                    flagA = True

                else:
                    flagA = False    

                yaInicializoFlagA = True

            if flagA: 
                geomA = featSubSegmento.geometry()
                puntos_contenidosA = self.obtenerPtsDeGeometria(geomA.buffer(0.01, 15))
                flagA = not flagA

            else:
                geomB = featSubSegmento.geometry()

                puntos_contenidosB =  self.obtenerPtsDeGeometria(geomB.buffer(0.01, 15))
                flagA = not flagA 


        posicionHallada = self.opcionesDePoscicion(idSegmento, puntos_contenidosA, puntos_contenidosB)
    
        print("@@@@@@@@  HALLADA  -> ", posicionHallada)    

        return posicionHallada
    
    ##########################################################
    
    def obtenerCapaSgmentoDividido_idSegmento(self):
        
        #obtengo el unico punto proyectado de la capa
        layer_puntoCerca = self.capaPtoCerca  
        ptoCerca = next(layer_puntoCerca.getFeatures())

        recorrido = self.obtenerSegmentoRecorrdioPorPuntoCercano(ptoCerca)
        self.auxiliarVerFeature("segmentoRec", "LineString",recorrido, self.verCapasEnMemoria)

        layer_output_recta = QgsProject.instance().mapLayersByName("output")[0]
        recta = next(layer_output_recta.getFeatures())
        self.auxiliarVerFeature("RectaDivisoria", "LineString",recta, self.verCapasEnMemoria)
        vertice0 = recorrido.geometry().vertexAt(0)
        vertice1 = recorrido.geometry().vertexAt(1)

        params = {
            'INPUT': "segmentoRec",
            'LINES': "RectaDivisoria",
            'OUTPUT': "memory:"
        }

        result = processing.run('native:splitwithlines', params)

        output_layer = result['OUTPUT']

        return (output_layer, recorrido['ID'], vertice0, vertice1, ptoCerca)

    ##########################################################
    def obtenerSegmentoRecorrdioPorPuntoCercano(self, punto):

        layer_Segmentos = self.cap_segmentosV

        for feature in layer_Segmentos.getFeatures():

            if punto.geometry().buffer(0.01, 8).intersects(feature.geometry()):

                self.auxiliarVerGeometria("bufferAlpto", "Polygon", punto.geometry().buffer(0.01, 8), self.verCapasEnMemoria)
                return feature
            
    ##########################################################
    def obtenerPtsDeGeometria(self, geometria):

        points_layer = QgsProject.instance().mapLayersByName('PosicionesProyectadas')[0]

        contained_points = []

        for point_feature in points_layer.getFeatures():
            point_geom = point_feature.geometry()

            if geometria.contains(point_geom):
                contained_points.append(int(point_feature['ID']))
        
        ordenados = sorted(contained_points)
         
        return (ordenados)      

    ##########################################################

    def obtenerPosDeVecinos(self, id_Segmento, maxSegmentos, maxPosiciones) :

        if id_Segmento > (maxSegmentos // 2):
            return self.obtenerPosDeVecinoDireccion(id_Segmento, +1, maxSegmentos, maxPosiciones)
        else:
            return self.obtenerPosDeVecinoDireccion(id_Segmento, -1, maxSegmentos, maxPosiciones)
        
    ##########################################################
    
    def opcionesDePoscicion(self, id_Segmento, listaA, listaB):

        maxSegmentos = self.cap_segmentosV.featureCount() - 1
        maxPosiciones = (QgsProject.instance().mapLayersByName(self.CapaPosicionesVigentes)[0]).featureCount()
        
        if len(listaA) != 0:
            posHallada = (max(listaA)+1)
            
        elif len(listaB) != 0:
            posHallada = min(listaB)
        elif id_Segmento == 0:  #listaA = listaB = vacio
            posHallada = 1
        elif id_Segmento == maxSegmentos:    
            posHallada = (maxPosiciones +1)
        else:
            return self.obtenerPosDeVecinos( id_Segmento, maxSegmentos, maxPosiciones)

        return posHallada                  


##########################################################################
################### Metodo expuesto calcular Posicion ####################
    
    def calcularPosicion (self, nombreCapaPosiciones, nombreCapaRecorridos, codRecorrido, ptoNuevo):
        
        self.ptoDadoAlta = 0
        self.puntoNuevo = QgsFeature()
        print(ptoNuevo.x())
        print(ptoNuevo.y())
        point = QgsPointXY(ptoNuevo.x(), ptoNuevo.y())
        self.puntoNuevo.setGeometry(QgsGeometry.fromPointXY(point))
        print(nombreCapaPosiciones)
        print(nombreCapaRecorridos)
        print(codRecorrido)
        self.CapaPosicionesVigentes =  nombreCapaPosiciones 
        self.CapaRecorridoVigente = nombreCapaRecorridos   
        self.nom_rut =  codRecorrido  
        self.verCapasEnMemoria = False
        self.vueltas = 3

        #Si existen de pasada anterior
        self.eliminarCapaEnMemoria("PosicionesProyectadas")
        self.eliminarCapaEnMemoria("RectaDivisoria")
        self.eliminarCapaEnMemoria("output")
        self.eliminarCapaEnMemoria("segmentoRec")
        self.eliminarCapaEnMemoria("segmento")
        print("Arranca el srcipt")

        self.crearVerticesDeUnRecorrido()      # nueva era ok->(Vertices) 
        print("pasa 1 ")
        self.crearSegmentosConVertices()       # nueva era ok->(SegmentosV)    
        print("pasa 2 ")
        self.proyectarPosicionesARecorrido()
        print("pasa 3 ")
        self.detectorPosicionesMal()
        print("pasa 4 ")
        self.proyectarPtoNuevoEnRecorrido(self.CapaRecorridoVigente) #-> (PtoCerca, segmento)
        print("pasa 5 ")
        pos = self.obtenerPosicionNuevo()
        print("pos: ")
        print(pos)
        print("******************************************************************************")

        return pos


    ##########################################################

    def reposicionarAPartirDePos(self, capa, posicion):

        try:
            capa.startEditing()

            #exp = QgsExpression(f'"POSICION" >= {posicion} or "COD_RECORRIDO" IS NULL')
            exp = QgsExpression(f'"POSICION" >= {posicion}')
            request = QgsFeatureRequest(exp)

            features = capa.getFeatures(request)

            field_idx_pos = capa.fields().indexOf('POSICION')
            #field_idx_rec = capa.fields().indexOf('COD_RECORRIDO')
            
            for feature in features:
                valorNuevo = int(round(feature['POSICION'])) + 1.0
                capa.changeAttributeValue(feature.id(), field_idx_pos , valorNuevo)

            capa.commitChanges()
            return True
        except:
            return False

##########################################################################
################### Metodo expuesto reordenar Alta #######################     

    def reordenarPuntosAlta(self, nombreCapaPosiciones, posicionNueva):
        print("llega a la calculadora")
        print(nombreCapaPosiciones)
        print(posicionNueva)
        #self.CapaPosicionesVigentes =  nombreCapaPosiciones
        #return self.reposicionarAPartirDePos(QgsProject.instance().mapLayersByName(self.CapaPosicionesVigentes)[0], posicionNueva)
        return True
        