import requests
import json
import configparser
import os
from qgis.core import QgsProject
from qgis.core import QgsEditorWidgetSetup
from qgis.utils import iface
from qgis.core import QgsAction
from qgis.PyQt import QtWidgets

#SI VAMOS A INVOCAR LA CONFIGURACION PARA LA CAPA ACTIVA:
#configuraCapaActiva()
#EJEMPLO configuraCapaActiva()    

#SI VAMOS A INVOCAR LA CONFIGURACION PARA TODAS LAS CAPAS DEL PROYECTO:
#configuraCapasProyecto()
#EJEMPLO configuraCapasProyecto() 

def cargarProperties():  
	thisfolder = os.path.dirname(os.path.abspath(__file__))
	initfile = os.path.join(thisfolder, 'config.properties')
	config = configparser.ConfigParser()
	config.read(initfile)
	return config

def invocarRestGet(urlServicio):
	try:
		headers = {'Accept': 'application/json'}
		response = requests.get(urlServicio, verify=False, headers=headers)
		return response.json()
	except:
		return None

def invocarRestPost(urlServicio, data):
	try:
		headers = {'Accept': 'application/json'}
		response = requests.post(urlServicio, data, verify=False, headers=headers)
		return response.json()
	except:
		return None

def obtenerValorCalculado(tabla, nombreUsuario, data, atributo):
	prop = cargarProperties()
	url = prop.get("ServicioRest", "urlCapas")
	responseAtributos = invocarRestPost(url+"getCalcFields?tabla="+tabla+"&username="+nombreUsuario, data)
	return responseAtributos[atributo]

def obtenerAtributosCapa(nombreUsuario, nombreCapa):
	prop = cargarProperties()
	url = prop.get("ServicioRest", "urlCapas")
	responseAtributos = invocarRestGet(url+"atributocapaformat?username="+nombreUsuario+"&capa="+nombreCapa)
	return responseAtributos
	
def atributoRequerido(nombreCapa, atributo):
	layer = QgsProject.instance().mapLayersByName(nombreCapa)[0]
	field_idx = layer.fields().indexFromName(atributo)
	layer.setConstraintExpression(field_idx, atributo + ' IS NOT NULL')

def atributoSoloLectura(nombreCapa, atributo):
	layer = QgsProject.instance().mapLayersByName(nombreCapa)[0]
	field_idx = layer.fields().indexFromName(atributo)
	form_config = layer.editFormConfig()
	form_config.setReadOnly(field_idx, True)
	layer.setEditFormConfig(form_config)

def ocultarAtributo(nombreCapa, atributo):
	layer = QgsProject.instance().mapLayersByName(nombreCapa)[0]
	field_idx = layer.fields().indexFromName(atributo)
	widget_setup = QgsEditorWidgetSetup('Hidden', {})
	layer.setEditorWidgetSetup(field_idx, widget_setup)

def cargaDateAtriburo(nombreCapa, atributo):
	layer = QgsProject.instance().mapLayersByName(nombreCapa)[0]
	config = {'allow_null': True, 'calendar_popup': True, 'display_format': 'dd/MM/yyyy', 'field_format': 'yyyy-MM-dd', 'field_iso_format': False}
	field_idx = layer.fields().indexFromName(atributo)
	widget_setup = QgsEditorWidgetSetup('DateTime',config)
	layer.setEditorWidgetSetup(field_idx, widget_setup)

def cargaCodigueraAtriburo(nombreCapa, atributo, list_values):
	layer = QgsProject.instance().mapLayersByName(nombreCapa)[0]
	config = {'map' : dict(list_values)}
	widget_setup = QgsEditorWidgetSetup('ValueMap',config)
	field_idx = layer.fields().indexFromName(atributo)
	layer.setEditorWidgetSetup(field_idx, widget_setup)

def procesarCodiguera(nombreUsuario, nombreCodiguera, pkNombre, valueNombre):
	prop = cargarProperties()
	url = prop.get("ServicioRest", "urlCapas")
	responseCodiguera = invocarRestGet(url+"codiguerasdata?username="+nombreUsuario)
	diccionarioCodiguera = dict()
	for datos in responseCodiguera:
		if datos["Codiguera"] == nombreCodiguera:
			tuplas = datos["Data"]
			for registro in tuplas:
				diccionarioCodiguera[registro[valueNombre]]=registro[pkNombre]
	return diccionarioCodiguera

def procesarDatosCapaCodiguera(nombreUsuario, nombreCapa):
	atributosCapa = obtenerAtributosCapa(nombreUsuario, nombreCapa)
	comboValue = atributosCapa["comboValue"]
	comboDesciption = atributosCapa["comboLabel"]
	valoresCodiguera = procesarCodiguera(nombreUsuario, nombreCapa, comboValue, comboDesciption)
	return valoresCodiguera

def configurarAtributo(nombreUsuario, nombreCapa, datosAtributo):
	tipo = ""
	mostrar = False
	soloLectura = False
	requerido = True
	nombreAtributo = ""
	
	if "tipo" in datosAtributo:
	    tipo = datosAtributo["tipo"]
	if "nombre_bd" in datosAtributo:
	    nombreAtributo = datosAtributo["nombre_bd"].upper()
	if "show" in datosAtributo:
	    mostrar = datosAtributo["show"]
	if "read_only" in datosAtributo:
	    soloLectura = datosAtributo["read_only"]	
	if "NILLABLE" in datosAtributo:
	    requerido = not datosAtributo["NILLABLE"]

	if  nombreAtributo != "":
		if mostrar:
			if tipo == "imm.gis.core.feature.ExternalAttribute":
				capaCodiguera = datosAtributo["capa_referenciada"]
				valoresCodiguera = procesarDatosCapaCodiguera(nombreUsuario, capaCodiguera)
				cargaCodigueraAtriburo(nombreCapa, nombreAtributo, valoresCodiguera)
			elif tipo == "java.util.Date":
				cargaDateAtriburo(nombreCapa, nombreAtributo)
			
			if soloLectura:
				atributoSoloLectura(nombreCapa, nombreAtributo)
			if requerido:
				atributoRequerido(nombreCapa, nombreAtributo)
		else:
			ocultarAtributo(nombreCapa, nombreAtributo)

def cargarCamposCalculados(nombreUsuario, nombreCapa, atributosCapa, atributosFormulario):
	
	diccionarioCamposCalculados = dict()
	for clave, valor in atributosFormulario.items():
		valorCalculado = ""
		mostrar = False
		if "valorCalculado" in valor:
		    valorCalculado = valor["valorCalculado"]
		if "show" in valor:
		    mostrar = valor["show"]
		if valorCalculado != "" and mostrar:
			diccionarioCamposCalculados[valor["nombre"]]=valor["label"]	
			
	cantidadCamposCalculados = len(diccionarioCamposCalculados)
	
	if cantidadCamposCalculados > 0:	
		prop = cargarProperties()
		url = prop.get("ServicioRest", "urlCapas")
		nombreActionCamposCalculados = prop.get("Actions", "nombreActionCamposCalculados")
		nombreCortoActionCamposCalculados = prop.get("Actions", "nombreCortoActionCamposCalculados")
		layer = QgsProject.instance().mapLayersByName(nombreCapa)[0]
		
		actionManager = layer.actions()
		actions = actionManager.actions()
		if len(actions) > 0:
			for a in actions:
				if a.name() == nombreActionCamposCalculados:
					layer.actions().removeAction(a.id())
		
		nombreTabla = atributosCapa['nombreTabla']
		comilla = "'"
		dobleComilla = '"'
		mas = "+"
		abre = comilla + dobleComilla + comilla + mas
		cierra = mas + comilla + dobleComilla + comilla
		text_comand = "from qgis.utils import iface"
		text_comand += "\nfrom qgis.PyQt import QtWidgets"
		text_comand += "\nimport requests"
		text_comand += "\nimport json"
		text_comand += "\n"
		text_comand += "\npry=QgsProject.instance()"
		text_comand += "\nurl = '" + url + "'"
		text_comand += "\n"
		text_comand += "\nlayer = iface.activeLayer()"
		text_comand += "\nuser = layer.source().split(' ')[0].split('=')[1].replace('\\'','') "
		text_comand += "\ngeom = [% "+abre+" geom_to_wkt(  $geometry, 10 ) "+cierra+" %]"
		text_comand += "\n"
		text_comand += "\nnombreTabla = '" + nombreTabla +"'"
		text_comand += "\n"
		text_comand += "\nheaders = {'Accept': 'application/json'}"
		text_comand += "\n"
		text_comand += "\ndata = {'_geometry': geom}"
		text_comand += "\nurlPost = url+'getCalcFields?tabla='+nombreTabla+'&username='+user"
		text_comand += "\nresponse = requests.post(urlPost, json=data, verify=False, headers=headers)"
		text_comand += "\ncamposCalculados = response.json()"
		text_comand += "\n"
		text_comand += "\nQtWidgets.QMessageBox.information(None, 'Campos Calculados', "
		i = 1
		for nombre, etiqueta in diccionarioCamposCalculados.items():
	    		if i == cantidadCamposCalculados:
	    			text_comand += "\n'"+etiqueta+": ' + camposCalculados['"+nombre+"']"
	    		else:
	    			text_comand += "\n'"+etiqueta+": ' + camposCalculados['"+nombre+"'] + '\\n' + "
	    		i=i+1
		text_comand += "\n)"

		camposCalculadosAction = QgsAction(1, 
				    nombreActionCamposCalculados, 
				    text_comand, 
				    None, 
				    capture=False, 
				    shortTitle=nombreCortoActionCamposCalculados, 
				    actionScopes={'Layer', 'Form', 'Canvas', 'Field', 'Feature'}
				    )
		layer.actions().addAction(camposCalculadosAction)

def configurarFormulario(nombreUsuario, nombreCapa, atributos):
	for clave, valor in atributos.items():
		configurarAtributo(nombreUsuario, nombreCapa, valor)

def procesarDatosCapa(nombreUsuario, nombreCapa):
	retorno = ""
	prop = cargarProperties()
	cargaCampCalc = prop.get("Configuracion", "cargaCamposCalculados")
	atributosCapa = obtenerAtributosCapa(nombreUsuario, nombreCapa)
	if atributosCapa is not None:
		esCodiguera = atributosCapa["esCodiguera"]
		atributosFormulario = atributosCapa["atributos"]
		if not esCodiguera :
			configurarFormulario(nombreUsuario, nombreCapa, atributosFormulario)
			if cargaCampCalc == "S":
				cargarCamposCalculados(nombreUsuario, nombreCapa, atributosCapa, atributosFormulario)
			retorno = "Se Configuró Correctamente La Capa: " + nombreCapa
	else:
		retorno = "No Existe Metadata De La Capa: " + nombreCapa
	
	return retorno

def configuraCapaActiva():
	retorno = ""
	layer = iface.activeLayer()
	if layer is not None:
		workspace = ""
		layername = ""
		if len(layer.name().split(":")) > 1:
			workspace = layer.name().split(":")[0]
			layername = layer.name().split(":")[1]
			layer.setName(layername)
		nombreUsuario = layer.source().split(' ')[0].split('=')[1].replace('\'','')
		nombreCapa = layer.name()
		retorno = procesarDatosCapa(nombreUsuario, nombreCapa)
		if workspace != "":
			layer.setName(workspace+":"+layername)
	else:
		retorno = "No Existe Capa Activa"
	QtWidgets.QMessageBox.information(None, "Proceso Configuración Capas", retorno)

def configuraCapasProyecto():
	retorno = ""
	for layer in QgsProject.instance().mapLayers().values():
		workspace = ""
		layername = ""
		if len(layer.name().split(":")) > 1:
			workspace = layer.name().split(":")[0]
			layername = layer.name().split(":")[1]
			layer.setName(layername)
		nombreUsuario = layer.source().split(' ')[0].split('=')[1].replace('\'','')
		nombreCapa = layer.name()
		retorno += "\n"+procesarDatosCapa(nombreUsuario, nombreCapa)
		if workspace != "":
			layer.setName(workspace+":"+layername)
	QtWidgets.QMessageBox.information(None, "Proceso Configuración Capas", retorno)
