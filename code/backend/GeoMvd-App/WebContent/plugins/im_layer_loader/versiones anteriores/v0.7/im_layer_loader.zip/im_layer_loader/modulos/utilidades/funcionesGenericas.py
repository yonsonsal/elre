from .configProperties import ConfigProperties


class FuncionesGenericas:

    @staticmethod
    def getUrlServicios(aplicacion):
        url = ConfigProperties.getPropery("ServicioRest", "urlCapas")
        url = url.replace("replaceAppName", aplicacion)
        return url