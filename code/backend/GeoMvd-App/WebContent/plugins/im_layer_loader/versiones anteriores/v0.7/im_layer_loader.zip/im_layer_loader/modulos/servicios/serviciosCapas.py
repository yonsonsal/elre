from .serviciosRest import ServiciosRest
from ..utilidades.configProperties import ConfigProperties
from ..utilidades.funcionesGenericas import FuncionesGenericas


class ServiciosCapas :

	@staticmethod
	def obtenerValorCalculado(tabla, nombreUsuario, data, atributo, aplicacion):
		url = FuncionesGenericas.getUrlServicios(aplicacion)
		responseAtributos = ServiciosRest.invocarRestPost(url+"getCalcFields?tabla="+tabla+"&username="+nombreUsuario, data)
		return responseAtributos[atributo]
	
	@staticmethod
	def obtenerAtributosCapa(nombreUsuario, nombreCapa, aplicacion):
		url = FuncionesGenericas.getUrlServicios(aplicacion)
		responseAtributos = ServiciosRest.invocarRestGet(url+"atributocapaformat?username="+nombreUsuario+"&capa="+nombreCapa)
		return responseAtributos

	@staticmethod
	def obtenerCodiguerasData(nombreUsuario, aplicacion):
		url = FuncionesGenericas.getUrlServicios(aplicacion)
		responseCodiguera = ServiciosRest.invocarRestGet(url+"codiguerasdata?username="+nombreUsuario)
		return responseCodiguera
