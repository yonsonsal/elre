from qgis.core import *
from qgis.gui import *

from ...formularios.atributosFormulario import AtributosFormularios


class FuncionesUccriu:

    @staticmethod
    def disponibilizarFuncionesParaExpresiones():
        # Create a function factory and register the functions
        factory = QgsExpression()
        
    @staticmethod
    def filtrarDescripcionRemocion():
         layerName = 'uccriu:e_v_uccriu_obras_emergencia' 
         capaCodiguera = 'uccriu:c_v_fu_ubic_tipo_remocion' 
         field = 'NRO_REMOCION' 
         pk = 'NRO_OBRA' 
         value = 'UBIC_TREM' 
         desc = '' 
         filter = "current_value('NRO_OBRA') = attribute( $currentfeature, 'NRO_OBRA' )"         
         AtributosFormularios.cargaCodigueraAtributoCapa(layerName, capaCodiguera, field, pk, value, desc, filter)

