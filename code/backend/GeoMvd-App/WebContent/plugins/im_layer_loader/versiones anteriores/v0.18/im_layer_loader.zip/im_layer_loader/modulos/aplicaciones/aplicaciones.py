from PyQt5.QtCore import QSettings

from .bicis.bicis import Bicis
from .dfr.dfr import Dfr
from .dfr.funcionesDfr import FuncionesDfr
from .etnia.etnia import Etnia
from .geofact.geofact import Geofact
from .geoprep.geoprep import Geoprep
from qgis.core import QgsProject, QgsExpression
import os
import shutil

from ..formularios.atributosFormulario import AtributosFormularios
from ..servicios import serviciosUbicacionesRestWEB
from ..servicios.serviciosCapas import ServiciosCapas


class Aplicaciones:

    @staticmethod
    def capasAplicacion(*args):
        workspace = args[0].capitalize()
        class_instance = None
        try:
            class_instance = globals()[workspace]()
        except:
            pass
        if class_instance is not None:
            class_instance.procesarAplicacion(*args)
        else:
            print("No tenemos implementada la clase: " + workspace)


    @staticmethod
    def cargarArchivoFunciones():
        nombreArchivo = 'serviciosUbicacionesRestWEB.py'
        # Define the path to your Python file
        thisfolder = os.path.dirname(os.path.abspath(__file__))
        origen_path = os.path.join(thisfolder, '../servicios/'+nombreArchivo)

        # Define the path to the expressions folder
        destino_path = os.path.join(thisfolder, '../../../../expressions/'+nombreArchivo)

        # Copy the file to the expressions folder
        shutil.copyfile(origen_path, destino_path)

    @staticmethod
    def disponibilizarFuncionesParaExpresiones():
        # Create a function factory and register the functions
        factory = QgsExpression()
        factory.registerFunction(AtributosFormularios.getCampoDefault)



