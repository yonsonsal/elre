from qgis.core import *
from qgis.gui import *

from .serviciosRest import ServiciosRest
from ..properties.configProperties import ConfigProperties


@qgsfunction(args='auto', group='ServiciosUbicacionesApiRest', usesgeometry=True, referenced_columns=[])
def getNombreMunicipioDadosXY(x, y, feature, parent):
    servicio = "municipios/municipioPunto?x="+str(x)+"&y="+str(y)
    respuesta = getServicioUbicacionesRestWEB(servicio)
    return respuesta.get("nombre")

def getServicioUbicacionesRestWEB(servicio):
    url = ConfigProperties.getPropery("ServicioRest", "urlubicacionesRestWEB")
    response = ServiciosRest.invocarRestGet(url+servicio)
    return response