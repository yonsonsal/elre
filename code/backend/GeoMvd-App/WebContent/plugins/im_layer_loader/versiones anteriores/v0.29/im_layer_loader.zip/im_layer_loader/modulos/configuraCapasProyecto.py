from qgis.core import QgsMapLayerType
from qgis.core import QgsProject

from .servicios.serviciosCapas import ServiciosCapas
from .formularios.formulario import Formulario
from .utilidades.funcionesExportacion import FuncionesExportacion
from .utilidades.funcionesGenericas import FuncionesGenericas
from .utilidades.funcionesMapa import FuncionesMapa


class ConfiguraCapasProyecto :

	def __procesarDatosCapa(self, nombreUsuario, nombreCapa, workspace):
		retorno = ""
		atributosCapa = ServiciosCapas.obtenerAtributosCapa(nombreUsuario, nombreCapa, workspace)
		if atributosCapa is not None:
			esCodiguera = atributosCapa["esCodiguera"]
			atributosFormulario = atributosCapa["atributos"]
			if not esCodiguera :
				editable = atributosCapa["editable"]
				tipo = atributosCapa["datos"]["tipo"]
				#VER QUE DEJAMOS PARA DETECTAR SI LA CAPA ES EDITABLE O NO
				#LA IDEA ORIGINAL ES USAR EL ATRIBUTO EDITABLE DEL .APP
				#PERO DEPENDE DEL ROL DEL USUARIO LOGUEADO SI TIENE EL ROL DE EDICION DE LA CAPA
				#POR MIENTRAS PODEMOS USAR LA DEFINICION DEL TIPO DEL .ORI PARA VER SI:
				#ES WFS ES EDITABLE Y SI ES WMS ES DE CONSULTA
				if tipo.upper() == "WFS":
					editable = True
				Formulario.configurarFormulario(nombreUsuario, nombreCapa, atributosCapa, atributosFormulario, workspace)

				if not editable:
					FuncionesMapa.setCapaSoloLectura(nombreCapa, True)

				#retorno = "Se Configuró Correctamente La Capa: " + nombreCapa
				retorno = ""
		else:
			retorno = "No Existe Metadata De La Capa: " + nombreCapa
		
		return retorno

	@staticmethod
	def configuraCapasProyecto():
		retorno = ""
		if len(QgsProject.instance().mapLayers().values()) > 0:
			for layer in QgsProject.instance().mapLayers().values():
				if layer.type() == QgsMapLayerType.VectorLayer and len(layer.name().split(":")) > 1:
					workspace = ""
					layername = ""
					if len(layer.name().split(":")) > 1:
						workspace, layername = FuncionesGenericas.getLayerName(layer.name())
						layer.setName(layername)
					nombreUsuario = FuncionesGenericas.getUserLayer(layer.source())
					nombreCapa = layer.name()
					conf = ConfiguraCapasProyecto()
					retorno += "\n"+conf.__procesarDatosCapa(nombreUsuario, nombreCapa, workspace)
					if workspace != "":
						layer.setName(workspace+":"+layername)
		else:
			retorno = "\nNo Existen Capas Agregadas"
		return retorno
