from qgis.core import *
from qgis.gui import *


class FuncionesUtap:

    @staticmethod
    def disponibilizarFuncionesParaExpresiones():
        # Create a function factory and register the functions
        factory = QgsExpression()
        factory.registerFunction(FuncionesUtap.obtenerIdPuestaParaLuminaria)

    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def obtenerIdPuestaParaLuminaria(feature, parent):
        idPuesta = "id_puesta"
        nombreCapaPuestas = 'utap:e_utap_puesta'
        gidCapaPuestas = "gid"
        datoActual = feature.attribute(idPuesta)

        dato = None
        if datoActual is not None and datoActual.__class__.__name__ != 'QVariant':
            dato = int(datoActual)
        else:
            try:
                layer = QgsProject.instance().mapLayersByName(nombreCapaPuestas)[0]
                if layer.isValid():
                    selected_features = layer.selectedFeatures()
                    if len(selected_features) > 0:
                        dato = selected_features[0][gidCapaPuestas]
            except:
                dato = None
        return dato