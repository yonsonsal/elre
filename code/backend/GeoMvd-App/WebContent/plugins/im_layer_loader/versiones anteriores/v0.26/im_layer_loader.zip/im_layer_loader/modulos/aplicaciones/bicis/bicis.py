from .funcionesBicis import FuncionesBicis


class Bicis:

    @staticmethod
    def procesarAplicacion(*args):

        FuncionesBicis.disponibilizarFuncionesParaExpresiones()

        workspace = args[0]
        layerName = args[1]
        print("Estoy en la clase Bicis")