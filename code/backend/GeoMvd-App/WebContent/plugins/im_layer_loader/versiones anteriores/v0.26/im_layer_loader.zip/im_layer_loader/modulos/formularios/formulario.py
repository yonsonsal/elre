from .atributosFormulario import AtributosFormularios
from .codigueras import Codigueras

class Formulario :

	def __configurarAtributo(self, nombreUsuario, nombreCapa, atributosCapa, datosAtributo, aplicacion):
		tipo = ""
		mostrar = False
		soloLectura = False
		requerido = True
		nombreAtributo = ""
		presentation = ""
		valorCalculado = ""
		persistible = False
		label = ""

		if "tipo" in datosAtributo:
		    tipo = datosAtributo["tipo"]
		if "nombre_bd" in datosAtributo:
		    nombreAtributo = datosAtributo["nombre_bd"]
		if "label" in datosAtributo:
			label = datosAtributo["label"]
		if "show" in datosAtributo:
		    mostrar = datosAtributo["show"]
		if "read_only" in datosAtributo:
		    soloLectura = datosAtributo["read_only"]	
		if "NILLABLE" in datosAtributo:
		    requerido = not datosAtributo["NILLABLE"]
		if "presentation" in datosAtributo:
		    presentation = datosAtributo["presentation"]
		if "valorCalculado" in datosAtributo:
			valorCalculado = datosAtributo["valorCalculado"]
		if "persistible" in datosAtributo:
			persistible = datosAtributo["persistible"]

		if nombreAtributo != "":
			if mostrar:
				if tipo == "imm.gis.core.feature.ExternalAttribute":
					capaCodiguera = datosAtributo["capa_referenciada"]
					valoresCodiguera = Codigueras.procesarDatosCapaCodiguera(nombreUsuario, capaCodiguera, aplicacion)
					AtributosFormularios.cargaCodigueraAtributo(nombreCapa, nombreAtributo, valoresCodiguera)
				elif tipo == "java.util.Date":
					AtributosFormularios.cargaDateAtributo(nombreCapa, nombreAtributo, requerido)
				elif tipo == "java.lang.String" and presentation == "TEXT_AREA":
					AtributosFormularios.cargaTextAreaAtributo(nombreCapa, nombreAtributo)

				if soloLectura:
					AtributosFormularios.atributoSoloLectura(nombreCapa, nombreAtributo)
				if tipo != "java.util.Date" and requerido:
					AtributosFormularios.atributoRequerido(nombreCapa, nombreAtributo)
				if valorCalculado != "" and persistible:
					AtributosFormularios.configuraCampoDefault(nombreCapa, atributosCapa, nombreAtributo, persistible, nombreUsuario, aplicacion, valorCalculado)
				if label != "":
					AtributosFormularios.configuraLabel(nombreCapa, nombreAtributo, label)
			else:
				AtributosFormularios.ocultarAtributo(nombreCapa, nombreAtributo)

	@staticmethod
	def configurarFormulario(nombreUsuario, nombreCapa, atributosCapa, atributos, aplicacion):
		form = Formulario()
		for clave, valor in atributos.items():
			form.__configurarAtributo(nombreUsuario, nombreCapa, atributosCapa, valor, aplicacion)
		AtributosFormularios.cargarCamposCalculados(nombreUsuario, nombreCapa, atributosCapa, atributos, aplicacion)
