from .serviciosRest import ServiciosRest
from ..utilidades.configProperties import ConfigProperties


class ServiciosCapas :

	@staticmethod
	def obtenerValorCalculado(tabla, nombreUsuario, data, atributo):
		url  = ConfigProperties.getPropery("ServicioRest", "urlCapas")
		responseAtributos = ServiciosRest.invocarRestPost(url+"getCalcFields?tabla="+tabla+"&username="+nombreUsuario, data)
		return responseAtributos[atributo]
	
	@staticmethod
	def obtenerAtributosCapa(nombreUsuario, nombreCapa):
		url  = ConfigProperties.getPropery("ServicioRest", "urlCapas")
		responseAtributos = ServiciosRest.invocarRestGet(url+"atributocapaformat?username="+nombreUsuario+"&capa="+nombreCapa)
		return responseAtributos
