from .atributosFormulario import AtributosFormularios
from .codigueras import Codigueras

class Formulario :

	def __configurarAtributo(self, nombreUsuario, nombreCapa, datosAtributo):
		tipo = ""
		mostrar = False
		soloLectura = False
		requerido = True
		nombreAtributo = ""
		
		if "tipo" in datosAtributo:
		    tipo = datosAtributo["tipo"]
		if "nombre_bd" in datosAtributo:
		    nombreAtributo = datosAtributo["nombre_bd"].upper()
		if "show" in datosAtributo:
		    mostrar = datosAtributo["show"]
		if "read_only" in datosAtributo:
		    soloLectura = datosAtributo["read_only"]	
		if "NILLABLE" in datosAtributo:
		    requerido = not datosAtributo["NILLABLE"]

		if  nombreAtributo != "":
			if mostrar:
				if tipo == "imm.gis.core.feature.ExternalAttribute":
					capaCodiguera = datosAtributo["capa_referenciada"]
					valoresCodiguera = Codigueras.procesarDatosCapaCodiguera(nombreUsuario, capaCodiguera)
					AtributosFormularios.cargaCodigueraAtriburo(nombreCapa, nombreAtributo, valoresCodiguera)
				elif tipo == "java.util.Date":
					AtributosFormularios.cargaDateAtriburo(nombreCapa, nombreAtributo)
				
				if soloLectura:
					AtributosFormularios.atributoSoloLectura(nombreCapa, nombreAtributo)
				if requerido:
					AtributosFormularios.atributoRequerido(nombreCapa, nombreAtributo)
			else:
				AtributosFormularios.ocultarAtributo(nombreCapa, nombreAtributo)
				
	@staticmethod
	def configurarFormulario(nombreUsuario, nombreCapa, atributos):
		form = Formulario()
		for clave, valor in atributos.items():
			form.__configurarAtributo(nombreUsuario, nombreCapa, valor)
