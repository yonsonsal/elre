import requests
import json
import configparser

class ServiciosRest :

	@staticmethod
	def invocarRestGet(urlServicio):
		try:
			headers = {'Accept': 'application/json'}
			response = requests.get(urlServicio, verify=False, headers=headers)
			return response.json()
		except:
			return None

	@staticmethod
	def invocarRestPost(urlServicio, data):
		try:
			headers = {'Accept': 'application/json'}
			response = requests.post(urlServicio, data, verify=False, headers=headers)
			return response.json()
		except:
			return None
