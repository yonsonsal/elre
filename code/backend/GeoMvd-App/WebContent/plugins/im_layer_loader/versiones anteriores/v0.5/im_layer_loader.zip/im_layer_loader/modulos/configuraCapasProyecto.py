from qgis.core import QgsProject
from qgis.utils import iface
from .servicios.serviciosCapas import ServiciosCapas
from .formularios.formulario import Formulario
from .formularios.camposCalculados import CamposCalculados
from .utilidades.configProperties import ConfigProperties


class ConfiguraCapasProyecto :

	def __procesarDatosCapa(self, nombreUsuario, nombreCapa):
		retorno = ""
		cargaCampCalc  = ConfigProperties.getPropery("Configuracion", "cargaCamposCalculados")
		atributosCapa = ServiciosCapas.obtenerAtributosCapa(nombreUsuario, nombreCapa)
		if atributosCapa is not None:
			esCodiguera = atributosCapa["esCodiguera"]
			atributosFormulario = atributosCapa["atributos"]
			if not esCodiguera :
				Formulario.configurarFormulario(nombreUsuario, nombreCapa, atributosFormulario)
				if cargaCampCalc == "S":
					CamposCalculados.cargarCamposCalculados(nombreUsuario, nombreCapa, atributosCapa, atributosFormulario)
				retorno = "Se Configuró Correctamente La Capa: " + nombreCapa
		else:
			retorno = "No Existe Metadata De La Capa: " + nombreCapa
		
		return retorno

	@staticmethod
	def configuraCapaActiva():
		retorno = ""
		layer = iface.activeLayer()
		if layer is not None:
			workspace = ""
			layername = ""
			if len(layer.name().split(":")) > 1:
				workspace = layer.name().split(":")[0]
				layername = layer.name().split(":")[1]
				layer.setName(layername)
			nombreUsuario = layer.source().split(' ')[0].split('=')[1].replace('\'','')
			nombreCapa = layer.name()
			conf = ConfiguraCapasProyecto()
			retorno = conf.__procesarDatosCapa(nombreUsuario, nombreCapa)
			if workspace != "":
				layer.setName(workspace+":"+layername)
		else:
			retorno = "No Existe Capa Activa"
		return retorno

	@staticmethod
	def configuraCapasProyecto():
		retorno = ""
		if len(QgsProject.instance().mapLayers().values()) > 0:
			for layer in QgsProject.instance().mapLayers().values():
				workspace = ""
				layername = ""
				if len(layer.name().split(":")) > 1:
					workspace = layer.name().split(":")[0]
					layername = layer.name().split(":")[1]
					layer.setName(layername)
				nombreUsuario = layer.source().split(' ')[0].split('=')[1].replace('\'','')
				nombreCapa = layer.name()
				conf = ConfiguraCapasProyecto()
				retorno += "\n"+conf.__procesarDatosCapa(nombreUsuario, nombreCapa)
				if workspace != "":
					layer.setName(workspace+":"+layername)
		else:
			retorno = "No Existen Capas Agregadas"
		return retorno
