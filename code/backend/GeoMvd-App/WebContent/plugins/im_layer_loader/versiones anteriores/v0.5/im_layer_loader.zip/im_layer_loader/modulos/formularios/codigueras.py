from ..servicios.serviciosRest import ServiciosRest
from ..servicios.serviciosCapas import ServiciosCapas
from ..utilidades.configProperties import ConfigProperties

class Codigueras:

	def __procesarCodiguera(self, nombreUsuario, nombreCodiguera, pkNombre, valueNombre):
		url  = ConfigProperties.getPropery("ServicioRest", "urlCapas")
		responseCodiguera = ServiciosRest.invocarRestGet(url+"codiguerasdata?username="+nombreUsuario)
		diccionarioCodiguera = dict()
		for datos in responseCodiguera:
			if datos["Codiguera"] == nombreCodiguera:
				tuplas = datos["Data"]
				for registro in tuplas:
					diccionarioCodiguera[registro[valueNombre]]=registro[pkNombre]
		return diccionarioCodiguera

	@staticmethod
	def procesarDatosCapaCodiguera(nombreUsuario, nombreCapa):
		atributosCapa = ServiciosCapas.obtenerAtributosCapa(nombreUsuario, nombreCapa)
		comboValue = atributosCapa["comboValue"]
		comboDesciption = atributosCapa["comboLabel"]
		procCod = Codigueras()
		valoresCodiguera = procCod.__procesarCodiguera(nombreUsuario, nombreCapa, comboValue, comboDesciption)
		return valoresCodiguera
