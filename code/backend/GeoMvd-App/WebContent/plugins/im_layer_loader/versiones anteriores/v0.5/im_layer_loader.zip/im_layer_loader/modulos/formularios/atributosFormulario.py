from qgis.core import QgsProject
from qgis.core import QgsEditorWidgetSetup


class AtributosFormularios :

	@staticmethod
	def atributoRequerido(nombreCapa, atributo):
		layer = QgsProject.instance().mapLayersByName(nombreCapa)[0]
		field_idx = layer.fields().indexFromName(atributo)
		layer.setConstraintExpression(field_idx, atributo + ' IS NOT NULL')

	@staticmethod
	def atributoSoloLectura(nombreCapa, atributo):
		layer = QgsProject.instance().mapLayersByName(nombreCapa)[0]
		field_idx = layer.fields().indexFromName(atributo)
		form_config = layer.editFormConfig()
		form_config.setReadOnly(field_idx, True)
		layer.setEditFormConfig(form_config)

	@staticmethod
	def ocultarAtributo(nombreCapa, atributo):
		layer = QgsProject.instance().mapLayersByName(nombreCapa)[0]
		field_idx = layer.fields().indexFromName(atributo)
		widget_setup = QgsEditorWidgetSetup('Hidden', {})
		layer.setEditorWidgetSetup(field_idx, widget_setup)

	@staticmethod
	def cargaDateAtriburo(nombreCapa, atributo):
		layer = QgsProject.instance().mapLayersByName(nombreCapa)[0]
		config = {'allow_null': True, 'calendar_popup': True, 'display_format': 'dd/MM/yyyy', 'field_format': 'yyyy-MM-dd', 'field_iso_format': False}
		field_idx = layer.fields().indexFromName(atributo)
		widget_setup = QgsEditorWidgetSetup('DateTime',config)
		layer.setEditorWidgetSetup(field_idx, widget_setup)

	@staticmethod
	def cargaCodigueraAtriburo(nombreCapa, atributo, list_values):
		layer = QgsProject.instance().mapLayersByName(nombreCapa)[0]
		config = {'map' : dict(list_values)}
		widget_setup = QgsEditorWidgetSetup('ValueMap',config)
		field_idx = layer.fields().indexFromName(atributo)
		layer.setEditorWidgetSetup(field_idx, widget_setup)
