class Geofact:

    @staticmethod
    def procesarAplicacion(*args):
        workspace = args[0]
        layerName = args[1]
        print("Estoy en la clase Geofact")