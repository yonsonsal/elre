from qgis.PyQt import QtWidgets
from qgis.core import *
from qgis.gui import *

from PyQt5.QtWidgets import QProgressDialog
from qgis.utils import iface

from .auxiliaresDfr import AuxiliaresDfr
from .calculadora_de_posiciones import CalculadoraDePosiciones


class FuncionesDfr:

    @staticmethod
    def disponibilizarFuncionesParaExpresiones():
        # Create a function factory and register the functions
        factory = QgsExpression()
        factory.registerFunction(FuncionesDfr.calcularPosicionDfr)
        factory.registerFunction(FuncionesDfr.getRegionDfr)
        factory.registerFunction(FuncionesDfr.getTipoPuntoLevanteDfr)

    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getRegionDfr(feature, parent):
        regionActual = feature.attribute("REGION")
        region = 1 #Region Este
        if regionActual is not None:
            region = regionActual
        return region

    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getTipoPuntoLevanteDfr(feature, parent):
        tplActual= feature.attribute("TIPO_PUNTO_LEVANTE")
        tpl = 1 #CL
        if tplActual is not None:
            tpl = tplActual
        return tpl

    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def calcularPosicionDfr(feature, parent):
        nombreCapaPosicionesRecorrido = "dfr:E_DF_POSICIONES_RECORRIDO"
        nombreCapaRutasRecorrido = "dfr:E_DF_RUTAS_RECORRIDO"
        codRecorrido = feature.attribute("COD_RECORRIDO")
        posicionActual = feature.attribute("POSICION")

        geom = feature.geometry().asWkt()
        qgs_geom = QgsGeometry.fromWkt(geom)
        qgs_point = qgs_geom.asPoint()
        qgs_point_xy = QgsPointXY(qgs_point)
        posicion = 0
        if posicionActual is not None:
            posicion = int(posicionActual)
        else:
            try:
                calculadora = CalculadoraDePosiciones()
                posicion = calculadora.calcularPosicion(nombreCapaPosicionesRecorrido, nombreCapaRutasRecorrido, codRecorrido, qgs_point_xy )
            except:
                posicion = NULL
        return posicion

    @staticmethod
    def despuesAgregarPosicionesRecorrido(featureId):
        layerName="dfr:E_DF_POSICIONES_RECORRIDO"
        layer = QgsProject.instance().mapLayersByName(layerName)[0]
        feature = layer.getFeature(featureId)

        feature = AuxiliaresDfr.inicializoAtributosPosicionesRecorrido(feature)

        layer.updateFeature(feature)
        layer.triggerRepaint()

        #aca habria que llamar a la funcion que renumera
        reordenado = False
        try:
            posicionNueva = 0
            if feature.attribute("POSICION") is not None:
                posicionNueva = int(feature.attribute("POSICION"))
                codRecorrido = feature.attribute("COD_RECORRIDO")
                calculadora = CalculadoraDePosiciones()
                FuncionesDfr.desconectarFuncionesPosicionesRecorrido(layer)
                reordenado = calculadora.reordenarPuntosAlta(layerName, codRecorrido, posicionNueva)
                AuxiliaresDfr.marcarUltimaPosicionRecorridoPosicionesRecorrido(layerName, codRecorrido)
                FuncionesDfr.conectarFuncionesPosicionesRecorrido(layer)
        except:
            reordenado = False

        if not reordenado:
            QtWidgets.QMessageBox.information(None, "Proceso Alta Posicion Recorrido", "Se produjo un error al ordenar el recorrido")

    @staticmethod
    def despuesBorrarPosicionesRecorrido(featureId):
        layerName="dfr:E_DF_POSICIONES_RECORRIDO"
        layer = QgsProject.instance().mapLayersByName(layerName)[0]
        feature = list(layer.dataProvider().getFeatures( QgsFeatureRequest( featureId ) ))[0]
        #aca habria que llamar a la funcion que renumera
        reordenado = False
        try:
            posicionNueva = 0
            if feature.attribute("POSICION") is not None:
                posicionNueva = int(feature.attribute("POSICION"))
                codRecorrido = feature.attribute("COD_RECORRIDO")
                calculadora = CalculadoraDePosiciones()
                FuncionesDfr.desconectarFuncionesPosicionesRecorrido(layer)
                reordenado = calculadora.reordenarPuntosBaja(layerName, codRecorrido, posicionNueva)
                AuxiliaresDfr.marcarUltimaPosicionRecorridoPosicionesRecorrido(layerName, codRecorrido)
                FuncionesDfr.conectarFuncionesPosicionesRecorrido(layer)
        except:
            reordenado = False

        if not reordenado:
            QtWidgets.QMessageBox.information(None, "Proceso Baja Posicion Recorrido", "Se produjo un error al ordenar el recorrido")

    @staticmethod
    def despuesModificarAtributosPosicionesRecorrido(featureId, idx, value):
        layerName="dfr:E_DF_POSICIONES_RECORRIDO"
        layer = QgsProject.instance().mapLayersByName(layerName)[0]
        field_idx = layer.fields().indexFromName("FECHA_HASTA")
        if idx == field_idx:
            feature = layer.getFeature(featureId)
            posicion = int(feature.attribute("POSICION"))
            codRecorrido = feature.attribute("COD_RECORRIDO")
            feature = AuxiliaresDfr.bajaLogicaPosicionesRecorrido(feature)
            layer.updateFeature(feature)
            calculadora = CalculadoraDePosiciones()
            FuncionesDfr.desconectarFuncionesPosicionesRecorrido(layer)
            reordenado = calculadora.reordenarPuntosBaja(layerName, codRecorrido, posicion)
            AuxiliaresDfr.marcarUltimaPosicionRecorridoPosicionesRecorrido(layerName, codRecorrido)
            FuncionesDfr.conectarFuncionesPosicionesRecorrido(layer)

    @staticmethod
    def conectarFuncionesPosicionesRecorrido(layer):
        layer.featureAdded.connect(FuncionesDfr.despuesAgregarPosicionesRecorrido)
        layer.featureDeleted.connect(FuncionesDfr.despuesBorrarPosicionesRecorrido)
        layer.attributeValueChanged.connect(FuncionesDfr.despuesModificarAtributosPosicionesRecorrido)

    @staticmethod
    def desconectarFuncionesPosicionesRecorrido(layer):
        layer.featureAdded.disconnect(FuncionesDfr.despuesAgregarPosicionesRecorrido)
        layer.featureDeleted.disconnect(FuncionesDfr.despuesBorrarPosicionesRecorrido)
        layer.attributeValueChanged.disconnect(FuncionesDfr.despuesModificarAtributosPosicionesRecorrido)