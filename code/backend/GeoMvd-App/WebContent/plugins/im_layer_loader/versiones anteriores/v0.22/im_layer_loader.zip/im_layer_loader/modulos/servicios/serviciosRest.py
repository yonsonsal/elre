import requests
from requests.auth import HTTPBasicAuth

class ServiciosRest :

	@staticmethod
	def invocarRestGet(urlServicio):
		try:
			headers = {'Accept': 'application/json'}
			response = requests.get(urlServicio, verify=False, headers=headers)
			return response.json()
		except:
			return None

	@staticmethod
	def invocarRestGetAuth(urlServicio, usuario, password):
		try:
			headers = {'Accept': 'application/json'}
			auth=HTTPBasicAuth(usuario, password)
			response = requests.get(urlServicio, verify=False, headers=headers, auth=auth)
			return response.json()
		except:
			return None

	@staticmethod
	def invocarRestGetAuthSld(urlServicio, usuario, password):
		try:
			headers = {'Accept': 'application/vnd.ogc.sld+xml'}
			auth=HTTPBasicAuth(usuario, password)
			response = requests.get(urlServicio, verify=False, headers=headers, auth=auth)
			return response.content
		except:
			return None

	@staticmethod
	def invocarRestPost(urlServicio, data):
		try:
			headers = {'Accept': 'application/json'}
			response = requests.post(urlServicio, json=data, verify=False, headers=headers)
			return response.json()
		except:
			return None

	@staticmethod
	def invocarRestPostCSV(urlServicio, data):
		try:
			headers = {'Accept': 'text/csv'}
			response = requests.post(urlServicio, json=data, verify=False, stream=True, headers=headers)
			return response
		except:
			return None