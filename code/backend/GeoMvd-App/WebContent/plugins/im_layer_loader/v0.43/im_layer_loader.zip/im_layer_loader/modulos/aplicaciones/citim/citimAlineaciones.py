from .funcionesCitim import FuncionesCitim
from ...formularios.atributosFormulario import AtributosFormularios


class CitimAlineaciones:

    @staticmethod
    def procesarAplicacion(*args):
        workspace = args[0]
        print("procesarAplicacion citim")

    @staticmethod
    def procesarCapasAplicacion(*args):
        workspace = args[0]
        layerName = args[1]
        print("procesarCapasAplicacion citim")

    @staticmethod
    def completarConfigAplicacion(*args):
        FuncionesCitim.armarUnionTrazosProyecto()
        AtributosFormularios.cargaDateAtributo('citim.alineaciones:e_citim_trazos', 'fecha_real', False)
        AtributosFormularios.cargaDateAtributo('citim.alineaciones:e_citim_trazos', 'fecha_apro', False)