from qgis.PyQt import QtWidgets
from qgis.core import *
from qgis.gui import *

from PyQt5.QtWidgets import QProgressDialog
from qgis.utils import iface

class FuncionesTramosLineas:
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getTipoConductor(feature, parent):
        datoActual = feature.attribute("cod_tipo_conductor")
        dato = 1
        if datoActual is not None:
            dato = datoActual
        return dato
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getTipoCable(feature, parent):
        datoActual = feature.attribute("cod_tipo_cable")
        dato = 1
        if datoActual is not None:
            dato = datoActual
        return dato
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getTipoTendido(feature, parent):
        datoActual = feature.attribute("cod_tipo_tendido")
        dato = "ST"
        if datoActual is not None:
            dato = datoActual
        return dato