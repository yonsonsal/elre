import logging

import requests
from PyQt5.QtWidgets import QMessageBox
from requests.auth import HTTPBasicAuth

from PyQt5.QtWidgets import QMessageBox

class ServiciosRest :

	@staticmethod
	def invocarRestGet(urlServicio):
		try:
			headers = {'Accept': 'application/json'}
			response = requests.get(urlServicio, verify=False, headers=headers)
			res_json = None
			if response.status_code == 200:
				try:
					res_json = response.json()
				except Exception as error:
					logging.error(f'Error al parsear response a json. En "invocarRestGet" en ServiciosRest: {type(error).__name__} : {error}. urlServicio: {urlServicio}. out:{response}')
			else:
				logging.error(f'Error en respuesta del servicio. En "invocarRestGet" en ServiciosRest: urlServicio: {urlServicio}. out:{response}, cod:{response.status_code}')
			return res_json
		except Exception as error:
			logging.error(f'Error en la red. En "invocarRestGet" en ServiciosRest: {type(error).__name__} : {error}. urlServicio: {urlServicio}')
			return None

	@staticmethod
	def invocarRestGetAuth(urlServicio, usuario, password):
		try:
			headers = {'Accept': 'application/json'}
			auth=HTTPBasicAuth(usuario, password)
			response = requests.get(urlServicio, verify=False, headers=headers, auth=auth)
			return response.json()
		except:
			return None

	@staticmethod
	def invocarRestGetAuthSld(urlServicio, usuario, password):
		try:
			headers = {'Accept': 'application/vnd.ogc.sld+xml'}
			auth=HTTPBasicAuth(usuario, password)
			response = requests.get(urlServicio, verify=False, headers=headers, auth=auth)
			return response.content
		except:
			return None

	@staticmethod
	def invocarRestPost(urlServicio, data):
		try:
			headers = {'Accept': 'application/json'}
			response = requests.post(urlServicio, json=data, verify=False, headers=headers)
			return response.json()
		except:
			return None

	@staticmethod
	def invocarRestPostCSV(urlServicio, data):
		try:
			headers = {'Accept': 'text/csv'}
			response = requests.post(urlServicio, json=data, verify=False, stream=True, headers=headers)
			return response
		except:
			return None