from .funcionesUtap import FuncionesUtap


class Utap:

    @staticmethod
    def procesarAplicacion(*args):
        workspace = args[0]
        FuncionesUtap.disponibilizarFuncionesParaExpresiones()

    @staticmethod
    def procesarCapasAplicacion(*args):
        workspace = args[0]
        layerName = args[1]