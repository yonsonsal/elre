from qgis.PyQt import QtWidgets
from qgis.core import *
from qgis.gui import *

from PyQt5.QtWidgets import QProgressDialog
from qgis.utils import iface

class FuncionesPuntosAlimentacion:
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getTipoConexion(feature, parent):
        datoActual = feature.attribute("cod_tipo_conexion")
        dato = 1
        if datoActual is not None:
            dato = datoActual
        return dato

    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getTipoAlimentacion(feature, parent):
        datoActual = feature.attribute("cod_tipo_alimentacion")
        dato = "TB"
        if datoActual is not None:
            dato = datoActual
        return dato