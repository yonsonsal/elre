from .funcionesUtap import FuncionesUtap
from .funcionesTramosLineas import FuncionesTramosLineas
from .funcionesPuntosAlimentacion import FuncionesPuntosAlimentacion
from .funcionesLuminarias import FuncionesLuminarias


class Utap:

    @staticmethod
    def procesarAplicacion(*args):
        workspace = args[0]
        FuncionesUtap.disponibilizarFuncionesParaExpresiones()

    @staticmethod
    def procesarCapasAplicacion(*args):
        workspace = args[0]
        layerName = args[1]
        
    @staticmethod
    def completarConfigAplicacion(*args):
        FuncionesTramosLineas.armarUnionTipoConductor()
        FuncionesPuntosAlimentacion.setearRestricciones()
        FuncionesLuminarias.setearRestricciones()
        
