from qgis.PyQt import QtWidgets
from qgis.core import *
from qgis.gui import *

from PyQt5.QtWidgets import QProgressDialog
from qgis.utils import iface

class FuncionesPuestas:
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getTipoSoporte(feature, parent):
        datoActual = feature.attribute("cod_tipo_puesta")
        dato = "CLTExxxyyy"
        if datoActual is not None:
            dato = datoActual
        return dato

    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getAlturaSoporte(feature, parent):
        datoActual = feature.attribute("altura_soporte")
        dato = 0
        if datoActual is not None:
            dato = datoActual
        return dato

    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getDistanciaCalzada(feature, parent):
        datoActual = feature.attribute("dist_calzada")
        dato = 0
        if datoActual is not None:
            dato = datoActual
        return dato

    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getInterdistancia(feature, parent):
        datoActual = feature.attribute("interdistancia")
        dato = 0
        if datoActual is not None:
            dato = datoActual
        return dato
        
    @staticmethod
    def setearRestricciones():
        layer = QgsProject.instance().mapLayersByName("utap:e_utap_puesta")[0]

        field_idx1 = layer.fields().indexFromName("gid")        
        layer.setConstraintExpression(field_idx1, "")
