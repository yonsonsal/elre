from qgis.PyQt import QtWidgets
from qgis.core import *
from qgis.gui import *

from PyQt5.QtWidgets import QProgressDialog
from qgis.utils import iface

class FuncionesLuminarias:
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getTipoLampara(feature, parent):
        datoActual = feature.attribute("cod_tipo_lampara")
        dato = 1
        if datoActual is not None:
            dato = datoActual
        return dato
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getModeloLuminaria(feature, parent):
        datoActual = feature.attribute("codmodelo")
        dato = 0
        if datoActual is not None:
            dato = datoActual
        return dato
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getMarcaLuminaria(feature, parent):
        datoActual = feature.attribute("cod_marca")
        dato = 1
        if datoActual is not None:
            dato = datoActual
        return dato
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getFabricanteLuminaria(feature, parent):
        datoActual = feature.attribute("cod_fabricante")
        dato = 0
        if datoActual is not None:
            dato = datoActual
        return dato
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getModeloBrazo(feature, parent):
        datoActual = feature.attribute("cod_modelo_brazo")
        dato = 0
        if datoActual is not None:
            dato = datoActual
        return dato
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getTipologia(feature, parent):
        datoActual = feature.attribute("cod_tipologia")
        dato = 0
        if datoActual is not None:
            dato = datoActual
        return dato
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getInstalador(feature, parent):
        datoActual = feature.attribute("cod_instalador")
        dato = 0
        if datoActual is not None:
            dato = datoActual
        return dato
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getTipoControl(feature, parent):
        datoActual = feature.attribute("cod_tipo_control")
        dato = 2
        if datoActual is not None:
            dato = datoActual
        return dato
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getTemperaturaColor(feature, parent):
        datoActual = feature.attribute("cod_temp_color")
        dato = 1
        if datoActual is not None:
            dato = datoActual
        return dato
    @qgsfunction(args='auto', group='CamposDefault', usesgeometry=True, referenced_columns=[])
    def getColorCarcasa(feature, parent):
        datoActual = feature.attribute("cod_color_carcasa")
        dato = 2
        if datoActual is not None:
            dato = datoActual
        return dato
        
    @staticmethod
    def setearRestricciones():
        layer = QgsProject.instance().mapLayersByName("utap:e_utap_luminaria")[0]
        
        field_idx1 = layer.fields().indexFromName("id_puesta")
        field_idx2 = layer.fields().indexFromName("id_nodo_controlador")
        layer.setConstraintExpression(field_idx1, "NOT (id_puesta <> '' AND id_nodo_controlador <> '') OR NOT (id_puesta IS NOT NULL AND id_nodo_controlador IS NOT NULL)")
        layer.setConstraintExpression(field_idx2, "NOT (id_puesta <> '' AND id_nodo_controlador <> '') OR NOT (id_puesta IS NOT NULL AND id_nodo_controlador IS NOT NULL)")

